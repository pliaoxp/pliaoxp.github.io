function ff=BCSUPP(x,a,b,c,d,yinitial)

% calculate y given x such that (x,y)'s distance from f(z) is d.
% point(x,y)'s distance from the curve f(z)=az^2+bz+c is d. Also, this
% point is outside of the curve f(z)
% yinitial gives the initial value to find zero.

y0=a*x^2+b*x+c;
ff=fzero(@(y) findy(y,a,b,c,d,x), yinitial);



    function gg=findy(y,a,b,c,d,x)
        % solving findy(y)=0 gives the desired y=BCSUPP;
        zstar=fzero(@(z) findzstar(z,a,b,c,x,y), x);
        gg=(zstar-x)^2+(a*zstar^2+b*zstar+c-y)^2-d^2;
        function g=findzstar(z,a,b,c,x,y)
            % solving findzstar(z)=0 gives the point zstar such that (zstar,
            % f(zstar)) on the curve f(z)'s distance to (x,y) is minimum
            g=4*a^2*z^3+6*a*b*z^2+(2*b^2+4*a*(c-y)+2)*z+2*(c-y)*b-2*x;
