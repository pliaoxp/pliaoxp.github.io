
 
function f=S(v,phi1,  H, phi3)
  
  % phi1 and phi3 are vector
% H = inv(X'X/n);
f=v'*H*(phi1+phi3)/2 +abs(v'*H)*(phi3-phi1)/2;


% f=v' *phi2*(phi1+phi3)/2   ;
 