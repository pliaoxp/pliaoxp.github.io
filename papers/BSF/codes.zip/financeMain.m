clear;

%s = RandStream('mt19937ar','seed',sum(100*clock));
%RandStream.setDefaultStream(s);




% gnt from dirichlet (1111)

T=200;% sample size n
N=5;
Lambda=randn(N,2);


% true m Sigma

mTrue=2*ones(N,1);  % m=ER
SigmaTrue=Lambda*Lambda'+eye(N);  % Sigma=Var(R)
phi1True=mTrue'*(SigmaTrue\mTrue);
phi2True=mTrue'*(SigmaTrue\ones(N,1));
phi3True=ones(1,N)*(SigmaTrue\ones(N,1));


mubar=1.4;
sigmabar2=6;%phi1True*mubar^2-2*phi2True*mubar+phi3True+1;

% Generate return R
for t=1:T
  %  R(:,t)=Lambda*randn(2,1)+randn(N,1)+mTrue;% N by T
   R(:,t)=Lambda*randn(2,1)+unifrnd(-2,2,N,1)+mTrue;% N by T  uniform error and factors
    % R(:,t)=Lambda*unifrnd(-2,2,2,1)+lognrnd(0,1,N,1)-exp(0.5)*ones(N,1)+mTrue;    % N by T
end;
K=1000;
v0=3;



B=1000; % number of posterior draws

phi1=ones(B,1); phi2=phi1; phi3=phi1;
for or=1:B
  tic
   % Generate beta from Dirichlet distribution
    Z=ones(T,1);
    for i=1:T
        Z(i)=gamrnd(1,1);
    end;
    S=sum(Z);
    betaP=Z/S; % beta is Dirichlet distributed T by 1
    gamma=betarnd(T,v0);  % parameter gamma
    
    %%% generate alpha
    for i=1:K
        u(i)=betarnd(1,v0);
    end;
    product(1)=1-u(1);
    alpha=ones(K,1);
    alpha(1)=u(1)*product(1);
    for j=2:K
        product(j)=product(j-1)*(1-u(j));
        alpha(j)=product(j)*u(j);
    end;
    
    xi=randn(N,K);
    
    % Generate Sigma and m
    Sigma1=(1-gamma)*xi*diag(alpha)*xi';
    Sigma2=gamma*R*diag(betaP)*R';
    Sigma3=(1-gamma)*xi*alpha+gamma*R*betaP;
    Sigma(:,:,or)=Sigma1+Sigma2-Sigma3*Sigma3';
    m(:,or)=Sigma3;
    
    % calculte phi
    phi1(or)=m(:,or)'*(Sigma(:,:,or)\m(:,or));
    phi2(or)=m(:,or)'*(Sigma(:,:,or)\ones(N,1));
    phi3(or)=ones(1,N)*(Sigma(:,:,or)\ones(N,1));
    
    % generate mu, uniformly, centered at the center of the quadratic curve
    %mu(or)=unifrnd(phi2(or)/phi1(or)-10,phi2(or)/phi1(or)+10);
    mu(or)=unifrnd(0,mubar);
    sigmaStar(or)=phi1(or)*mu(or)^2-2*phi2(or)*mu(or)+phi3(or);
    sigma2(or)=unifrnd(sigmaStar(or),sigmabar2);

clear Z S betaP  gamma u xi product alpha Sigma1 Sigma2 Sigma3 ;

or 
toc
end;


% Estimate boundary curve sigmamu versus mu based on posterior mean
phi1E=mean(phi1);
phi2E=mean(phi2);
phi3E=mean(phi3);

x=[0:0.01:1.5];
for i=1:length(x)
    y1(i)=phi1E*x(i)^2-2*phi2E*x(i)+phi3E;  % posterior mean boundary curve
    y2(i)=phi1True*x(i)^2-2*phi2True*x(i)+phi3True; % true boundary curve 
end;


scatter(mu,sigma2);
hold;
plot(x,y1,'--',x,y2);
hold;
 %-- is posterior

 
 
 
 % Find posterior mode for phi
 
 D=[phi1,phi2,phi3]; %  B x 3
 for i=1:B
     xval=[phi1(i);phi2(i);phi3(i)];
     post(i)=kernel(D,xval,0.2); % bandwidth 0.1 or 0.2
     clear xval;
     i
 end;
[kk,I]=max(post);
 mode=[phi1(I);phi2(I);phi3(I)] % posterior mode
 posE=[phi1E;phi2E;phi3E] % posterior mean
 
 
 
    
 % plot support function Case 1
clear p2 p1 f1 f1E f1M;
 
 p2=[0:0.01:1];
 for i=1:length(p2)
     p1(i)=sqrt(1-p2(i)^2);
     f1(i)=support(p1(i), p2(i),phi1True,phi2True,phi3True, mubar,sigmabar2); % true support function Case 1, 5,7 seem good
     f1E(i)=support(p1(i), p2(i),phi1E,phi2E,phi3E, mubar,sigmabar2);  %   posterior mean
     f1M(i)=support(p1(i), p2(i),mode(1),mode(2),mode(3), mubar,sigmabar2);  %  posterior mode
 end;
 plot(p2,f1E,'--',p2, f1M,p2,f1,':'); % -- is posterior mean,  : is mode
      
     
 
  % plot support function Case 2
clear p2 p1 f2 f2E f2M;
     p2=[-1:0.01:0];
 for i=1:length(p2)
     p1(i)=-sqrt(1-p2(i)^2);
     f2(i)=support(p1(i), p2(i),phi1True,phi2True,phi3True, mubar,sigmabar2); % true support function Case 1, 5,7 seem good
     f2E(i)=support(p1(i), p2(i),phi1E,phi2E,phi3E, mubar,sigmabar2);  % posterior mean
     f2M(i)=support(p1(i), p2(i),mode(1),mode(2),mode(3), mubar,sigmabar2);  % post mode
 end;
 plot(p2,f2E,'--',p2, f2M, p2,f2,':'); % -- is posterior
     
 
 
  % plot support function Case 4 not good
clear p2 p1 f4 f4E;
     p2=[0:0.01:1];
 for i=1:length(p2)
     p1(i)=-sqrt(1-p2(i)^2);
     f4(i)=support(p1(i), p2(i),phi1True,phi2True,phi3True, mubar,sigmabar2); % true support function Case 1, 5,7 seem good
     f4E(i)=support(p1(i), p2(i),phi1E,phi2E,phi3E, mubar,sigmabar2);  % estimated support function 
 end;
 plot(p2,f4E,'--',p2,f4); % -- is posterior
     
 
 
 
 
 % Find quantile for J(phi)

 for i=1:B
     for j=1:1000
          clear p1 p2;
         p1=unifrnd(-1,1);
         p2=sqrt(1-p1^2)*(2*binornd(1,0.5)-1);
         Delta(j)=abs(support(p1, p2,phi1(i),phi2(i),phi3(i), mubar,sigmabar2)-support(p1, p2,mode(1),mode(2),mode(3), mubar,sigmabar2));    % support(phi, p)-support(mode p)
     end;
     J(i)=max(Delta)*sqrt(T);
     clear Delta;
     i
 end;
 q=quantile(J,0.95); 
 
 
 a= mode(1); b=-2*mode(2); c=mode(3);     % curve is f(x)=ax^2+bx+c
 clear x y1 y3 yy z3;
 x=[-2:0.01:2];  
 
for i=1:length(x)
    y1(i)=phi1E*x(i)^2-2*phi2E*x(i)+phi3E;  % posterior mean boundary curve
    y2(i)=phi1True*x(i)^2-2*phi2True*x(i)+phi3True; % true boundary curve 
   yy(i)=a*x(i)^2+b*x(i)+c;  % initial value
    y3(i)=BCSUPP(x(i),a,b,c,q/sqrt(T),yy(i)-2); % confidence interval 0.95%
    z3(i)=y3(i);
    if y3(i)<0
        z3(i)=0;  % BCS truncated at zero
    end;
    
    if i>1
    if y1(i)>6 && y1(i-1)<6
        indey1=i;
    end;
    if y2(i)>6 && y2(i-1)<6
        indey2=i;
    end;
    if z3(i)>6 && z3(i-1)<6
        indey3=i;
    end;
    end
end;
 
 
 
 scatter(mu,sigma2,'.');
hold on ;
plot(x(1:indey1),y1(1:indey1),'--k',x(1:indey3),z3(1:indey3),':k',x(1:indey2-1),y2(1:indey2-1),'b', 'Linewidth', 4); %-- is posterior mean,  : is 95% confidence interval
%plot(x,y1,'--',x,y3,':',x,y2); %-- is posterior mean,  : is 95% confidence interval
 legend('posterior draws', 'posterior mean','95% BCS', 'true boundary');
title('Hansen-Jagannathan bounds ');
xlabel('\mu') % x-axis label
ylabel('\sigma^2') % x-axis label
figure(1);
axis([-3 5 -1 7]);
 hold off;
