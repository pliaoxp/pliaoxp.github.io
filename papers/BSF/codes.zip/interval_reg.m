clear;
% used in the paper, IV interval regression , projected on the first
% component
% fixed design
rep=500%1000; % number replications



n=100;
K=100; % tunraction
B=100; % number of posterior draws

%%%% DGP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=2;% dimension 10
r=M; % r>=M
 

tau=0.05;
e=zeros(M,1); e(1)=1;

%%%%%%%%%%%% true phi
X=rand(n,M);
muY1=0;
muY2=muY1+5;

H=inv(X'*X/n);

phi1true=1/n*X'*ones(n,1)*muY1;
phi3true=1/n*X'*ones(n,1)*muY2;
 
   

for kk=1:rep  % data replications

    
   % w1=X.*((randn(n,1)*sqrt(0.5)+muY1)*ones(1,M)); % n by M
    %w2=X.*((randn(n,1)*sqrt(0.5)+muY2)*ones(1,M)); % n by M
   
%    D=[w1';w2']; % p by n
 
V=X'*X/n^2;
w1=V^(1/2)*randn(M,1)+phi1true; % M by 1
w2=V^(1/2)*randn(M,1)+phi3true;

 
 
%% generate B posterior draws
%% generate Phi from normal
phi1=(V)^(1/2)*randn(M,B)+w1*ones(1,B); % M by B
phi3=(V)^(1/2)*randn(M,B)+w2*ones(1,B);
 
 
% posterior mean 
phi1M=w1;
phi3M=w2;
 
Sm1=S(e,phi1M, H, phi3M) ; % S_mode(e)
Sm2=S(-e,phi1M, H, phi3M) ; % S_mode(-e)

for or=1:B % calculate posterior quantiles of the support function
    S1(or)= S(e,phi1(:,or), H, phi3(:,or)) ;  % S(e)
    S2(or)= S(-e,phi1(:,or), H, phi3(:,or)) ; % S(-e)
    J(or)=sqrt(n)*max(S1(or)-Sm1, S2(or)-Sm2);
end;

q=quantile(J,0.95);

%% BCS for marginal set
 
lower(kk)= -Sm2-q/sqrt(n); % 
upper(kk)=Sm1+q/sqrt(n);
% BCS for the set is [lower, upper]

  %% for the partially identified parameter
 tildeq= q; %2*q
T=1000;  % uniformly generate T theta from its marginal space
theta=unifrnd(-40,40,T,1);
theta=sort(theta); % from small to large
k=0;coverage=0;
     while coverage<1-tau
        k=k+1;
        judge=(-S2-tildeq/sqrt(n)< theta(k)).*(S1+tildeq/sqrt(n)>theta(k));
        coverage=mean(judge); % coverage prob
     end;
     thetamin(kk)=theta(k);
     k=-1;coverage=0;
     while coverage<1-tau
        k=k+1;
        judge=  (-S2-tildeq/sqrt(n)< theta(T-k)).*(S1+tildeq/sqrt(n)>theta(T-k));
        coverage=mean(judge); % coverage prob
     end;
    thetamax(kk)=theta(T-k);
 
     % BCS for theta is [thetamin, thetamax]
     
   
   
%kk % number of replicated data
 
end;  % data replications



%% frequentist coverage of the ID set
lowtrue= -S(-e,phi1true, H, phi3true);
uppertrue=S(e,phi1true, H, phi3true);
[lowtrue , uppertrue] ;%true ID set for theta

s=(lower<lowtrue).*(upper>uppertrue);
mean(s)  % frequentist coverage of the set 


   %% verify frequentist coverage of the parameter

   s1=(thetamin<lowtrue).*(lowtrue<thetamax);
   s2=(thetamin<uppertrue).*(uppertrue<thetamax);
 min(mean(s1), mean(s2)) % mean(s1) is the frequentist coverage   for the point "lowtrue".
    
 vol2= mean(thetamax-thetamin) ; %volume is thetamax-thetamin 
 
 %% verify frequentist coverage of the parameter, but simply use the BCS of the ID set
 % this is likely to be very conservative

   s11=(lower<lowtrue).*(lowtrue<upper);
   s21=(lower<uppertrue).*(uppertrue<upper);
 min(mean(s11), mean(s21)) % mean(s1) is the frequentist coverage   for the point "lowtrue".
    
  vol3= mean(upper-lower ) ;  
  
  [vol2 vol3]
 