function y=kernel(D,x,h)
% D: n by dim data matrix
% x: dim by 1 vector to be evaluated at
% h: bandwidth

d=length(x);
n=length(D(:,1));

for i=1:n
    v=(D(i,:)-x')/h;
    f(i)=prod(normpdf(v));
    clear v;
end;
y=sum(f)/(n*h^d);
