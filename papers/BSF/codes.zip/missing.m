clear;

% used in the paper missing data, for the identified set


n=50;
alpha1=2; % 0.01--0.1
beta1=2; % 1

alpha2=alpha1; % 1
beta2=beta1; % 1
%deno=(alpha1+beta1)^2*(alpha1+beta1+1);  
%var1=alpha1*beta1/deno;
 

tau=0.05;
phi1true=0.7;
phi2true=0.5;
 B=1000;  % quantile
 OR=500;%1000 % COVERAGE
 
 LowerSucess=0;
 UpperSuccess=0;
 bothSuccess=0;
 M=zeros(n,1);
 Y=M;
 
 jj=1;

for or=1:OR  % coverage probability
    tic
    for i=1:n
        M(i)=binornd(1,phi1true);
        if M(i)==1 Y(i)=binornd(1,phi2true);
        else Y(i)=-10;
        end;
    end;
    n1(or)=sum(M); n2(or)=M'*Y;
    phi1M(or)=(n1(or)+alpha1-1)/(n+alpha1+beta1-2);
    phi2M(or)=(n2(or)+alpha2-1)/(n1(or)+alpha2+beta2-2);
    
    for i=1:B
        phi1(i,or)=betarnd(n1(or)+alpha1,n+beta1-n1(or));
        phi2(i,or)=betarnd(n2(or)+alpha2,n1(or)+beta2-n2(or));
        z1(i)=abs(phi1(i,or)*phi2(i,or)-phi1(i,or)-phi1M(or)*phi2M(or)+phi1M(or));
        z2(i)=abs(phi1(i,or)*phi2(i,or)-phi1M(or)*phi2M(or));
        J(i,or)=sqrt(n)*max(z1(i),z2(i));
    end;
    q(or)=quantile(J(:,or),1-tau); 
    LowerL(or)=phi1M(or)*phi2M(or)+q(or)/sqrt(n);
    LowerU(or)=phi1M(or)*phi2M(or)+1-phi1M(or)-q(or)/sqrt(n);
    UpperL(or)=phi1M(or)*phi2M(or)-q(or)/sqrt(n);
    UpperU(or)=phi1M(or)*phi2M(or)+1-phi1M(or)+q(or)/sqrt(n);
    
    if LowerL(or)>=0.35 && LowerU(or)<=0.65  
        LowerSucess=LowerSucess+1;
    end;
    if UpperL(or)<=0.35 && UpperU(or)>=0.65
        UpperSuccess=UpperSuccess+1;
        if LowerL(or)>=0.35 && LowerU(or)<=0.65 
            bothSuccess=bothSuccess+1;
        end;
    end;
    
    toc
    jj=jj+1
end;
    
   LowerRate= LowerSucess/OR
 UpperRate=UpperSuccess/OR
 BothRate=bothSuccess/OR
    
    
    