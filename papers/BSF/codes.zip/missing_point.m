clear;

% used in the paper missing data, for the partially identified parameter
 Delta=0; %0.1, 0.05  0% shrink to a singleton

alpha1=.1; % 0.01--0.1
beta1=.1; % 1, .1

alpha2=alpha1; % 1
beta2=beta1; % 1
%deno=(alpha1+beta1)^2*(alpha1+beta1+1);  
%var1=alpha1*beta1/deno;

n=500;
tau=0.05;
phi1true=1-Delta; %0.7
phi2true=0.5;
 B=1000;  % posterior draws
 OR=500;%1000 % COVERAGE
 T=2000; % num of uniformly generated theta
 
 jj=1;

for or=1:OR  % coverage probability
    %% generate data
    M=binornd(1,phi1true,n,1); % missing or not
    Y=binornd(1,phi2true,n,1).*M+(1-M).*(-10);
    n1=sum(M); n2=M'*Y;
    phi1M=(n1+alpha1-1)/(n+alpha1+beta1-2); % posterior mode
    phi2M=(n2+alpha2-1)/(n1+alpha2+beta2-2); % posterior mode
    
    %% generate B phi for fixed data
     phi1=betarnd(n1+alpha1,n+beta1-n1,B,1);
     phi2=betarnd(n2+alpha2,n1+beta2-n2, B, 1);
     z1=phi1.*phi2-phi1-(phi1M*phi2M-phi1M);
     z2=phi1M*phi2M-phi1.*phi2;
     J=sqrt(n)*max(z1,z2);
     q=quantile(J,1-tau); 
     tildeq=  2*q;
     %% generate theta
     theta=rand(T,1);
     theta=sort(theta); % from small to large
     k=0;coverage=0; % cov means coverage
     while coverage<1-tau
        k=k+1;
        judge=  (phi1.*phi2-tildeq/sqrt(n)< theta(k)).*(phi1.*phi2+1-phi1+tildeq/sqrt(n)>theta(k));
        coverage=mean(judge); % coverage prob
     end;
     thetamin(or)=theta(k);
     k=-1;coverage=0;
     while coverage<1-tau
        k=k+1;
        judge=  (phi1.*phi2-tildeq/sqrt(n)< theta(T-k)).*(phi1.*phi2+1-phi1+tildeq/sqrt(n)>theta(T-k));
        coverage=mean(judge); % coverage prob
     end;
    thetamax(or)=theta(T-k);
    jj=jj+1
     % BCS for theta is [thetamin, thetamax]
     
   
end;
    
     %% verify frequentist coverage
    lowtrue=phi1true*phi2true;
    uppertrue=phi1true*phi2true+1-phi1true;
    
   s1=(thetamin<lowtrue).*(lowtrue<thetamax);
   s2=(thetamin<uppertrue).*(uppertrue<thetamax);
 min(mean(s1), mean(s2)) % mean(s1) is the frequentist coverage   for the point  "lowtrue".
    
    