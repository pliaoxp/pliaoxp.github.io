function f=support(p1, p2,phi1,phi2,phi3, mubar,sigmabar2)

Xi=ones(2,1); 
D=phi2^2-phi1*phi3;

% CASE 1

if p2>0 && p1>0
    
    Xi(2)=sigmabar2;
    
    if sigmabar2>=phi1*mubar^2-2*phi2*mubar+phi3
        Xi(1)=mubar; 
    else
        Xi(1)=(phi2+sqrt(D+phi1*sigmabar2))/phi1;
    end;
    
end;


% CASE 2
if p2<0 && p1<0
    
    if phi2>0 && p1/p2<=phi2*(phi3<=sigmabar2)+sqrt(D+phi1*sigmabar2)*(phi3>sigmabar2)
        
        Xi(1)=phi2/phi1;
        Xi(2)=phi3-phi2^2/phi1;
    else 
        Xi(1)=(phi2-sqrt(D+phi1*sigmabar2))/phi1*(phi3>sigmabar2);
        Xi(2)=phi3*(phi3<=sigmabar2)+sigmabar2*(phi3>sigmabar2);
    end;
    
end;


 % CASE 4
if p2>0 && p1<0
    Xi(1)=(phi2-sqrt(D+phi1*sigmabar2))/phi1*(phi3>sigmabar2);
    Xi(2)=sigmabar2;
    
end;

% CASE 5

if p2==0 && p1==1
    
    if sigmabar2>=phi1*mubar^2-2*phi2*mubar+phi3
        Xi(1)=mubar;
        Xi(2)=(sigmabar2+phi1*mubar^2-2*phi2*mubar+phi3)/2;
    else
        Xi(1)=(phi2+sqrt(D+phi1*sigmabar2))/phi1;
        Xi(2)=sigmabar2;
    end;
end;




% CASE 6

if p2==0 && p1==-1
    
    if phi3<sigmabar2
        Xi(1)=0; Xi(2)=(phi3+sigmabar2)/2;
    else
        Xi(1)=(phi2-sqrt(D+phi1*sigmabar2))/phi1;
        Xi(2)=sigmabar2;
    end;
end;



% CASE 7

if p2==1 && p1==0
    
    Xi(1)=max(0,(phi2-sqrt(D+phi1*sigmabar2))/phi1);
    Xi(2)=sigmabar2;
    
end;




% CASE 8
if p2==-1 && p1==0
    
    eps=0.01
    if phi2>=0 && phi1*phi3-phi2^2>=0
        Xi(1)=phi2/phi1;
        Xi(2)=phi3-phi2^2/phi1;
    else if phi2<0
            Xi(1)=0; Xi(2)=phi3;
        else Xi(1)=((phi2-sqrt(D+phi1*eps))+mubar)/2;
            Xi(2)=eps;
        end;
    end;
end;




% CASE 3

if p2<0 && p1>0
    
    % 3.1
    mu=phi2/phi1-p1/(2*p2*phi1);
    I=2*phi2-2*phi1*mubar<=p1/p2<2*phi2;
    IIa=D<0 && D+phi1*sigmabar2>=0 && (phi2-sqrt(D+phi1*sigmabar2))/phi1<=mu<=(phi2+sqrt(D+phi1*sigmabar2))/phi1;
    IIbc=D==0 &&  (phi2-sqrt(D+phi1*sigmabar2))/phi1<=mu<=(phi2+sqrt(D+phi1*sigmabar2))/phi1;
    II=IIa || IIbc;
  if I && II
      Xi(1)=phi2/phi1-p1/(2*p2*phi1);
      Xi(2)=p1^2/(4*p2*phi1)-phi2^2/phi1+phi3;
  end;
  
  
  
  % 3.2
  if p1/p2>=2*phi2
      Xi(1)=0; Xi(2)=phi3*(phi3<=sigmabar2)+sigmabar2*(phi3>sigmabar2);
  end;
  
  
  %3.3
  IIa2=D<0 && D+phi1*sigmabar2>=0 && (phi2-sqrt(D+phi1*sigmabar2))/phi1<=mubar<=(phi2+sqrt(D+phi1*sigmabar2))/phi1;
  IIbc2=D==0 &&  (phi2-sqrt(D+phi1*sigmabar2))/phi1<=mubar<=(phi2+sqrt(D+phi1*sigmabar2))/phi1;
  II2=IIa2 || IIbc2;
  if 2*phi2-2*phi1*mubar>p1/p2 && II2
      Xi(1)=mubar;
      Xi(2)=phi1*mubar^2-2*phi2*mubar+phi3;
  end;
  
  
  % 3.4 is not possible,imaginary number
  % 3.5 is not possible
  
  % 3.6 
  J= mubar<(phi2-sqrt(D+sigmabar2*phi1))/phi1 || mubar>(phi2+sqrt(D+sigmabar2*phi1))/phi1;
  if 2*phi2-2*phi1*mubar>p1/p2 && D+phi1*sigmabar2>=0 && J
      Xi(1)=mubar; Xi(2)=sigmabar2;
  end;
  
  % 3.7 imaginary number
  
  %3.8
  K=mu<(phi2-sqrt(D+sigmabar2*phi1))/phi1 || mu>(phi2+sqrt(D+sigmabar2*phi1))/phi1;
  if I && D<0 && D+phi1*sigmabar2>=0 && K
      Xi(1)=mu;
      Xi(2)=sigmabar2;
  end;
  
  
  % 3.9
  if I && D==0 && K
      Xi(1)=mu; Xi(2)=sigmabar2;
  end;
  
  
  % 3.10
  if I && D==0 && mu==phi2/phi1
       Xi(1)=mu; Xi(2)=0;
  end;
 
  
      
      
      
      
end;

 f=Xi(1)*p1+Xi(2)*p2;























