function Sigma=matrix(u,C)
% return thresholded matrix
% u: N by T
% C: threshold constant, threshold correlation matrix, soft-threshold

[N,T]=size(u);
rate=1/sqrt(N)+sqrt(log(N))/sqrt(T);
Su=u*u'/(T-4);

if N>T*0.3
    SuDiag=diag(diag(Su));
    SuDiagHalf=SuDiag^(1/2);
    R=SuDiagHalf\Su/SuDiagHalf;
    th=abs(C)*rate;
    Rthresh=zeros(N,N);
    for i=1:N
        for j=1:i
            if abs(R(i,j))<th  && j<i
                Rthresh(i,j)=0;
            else if j==i 
                    Rthresh(i,j)=R(i,j);
                else
                    Rthresh(i,j)=sign(R(i,j))*(abs(R(i,j))-th);
                end;
            end;
            Rthresh(j,i)=Rthresh(i,j);
        end;
    end;
    Sigma=SuDiagHalf*Rthresh*SuDiagHalf;
else
    Sigma=Su;
end;