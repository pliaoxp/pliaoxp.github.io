 %% Monte Carlo Evaluation of Test

function [table1, table2,  zstat,  zstat_nomix] = allresults(kn,Rep,tau, missingj, disp_red)



N=   500  ; 
B= 1000;  %  bootstrap sample, 1000 for null

 
%% calibration
 
 
mon =1;  
shg=1.2;  

Sf=   1.0e-05 *[ 0.1198   0   0
   -0.0000    0.0377   0
   0   0    0.0264];

Sb= [0.2326   -0.2474    0.2603
   -0.2474    0.9224    0.0837
    0.2603    0.0837    0.9139];
meanb=[ -0.8763
   -0.2818
    0.2965];
scale = 0.0011; 
 
  
 %% start simulation

DAYS=     [1,5,10,15,20,30];
rejection_mix=nan(length(DAYS),Rep);
rejection_nomix=nan(length(DAYS),Rep);

IQR=nan(Rep, 1) ;
tstat=nan(Rep, 1) ;
IQR_nomix=nan(Rep, 1) ;
tstat_nomix=nan(Rep, 1) ;


for d =1:length(DAYS)
      day =DAYS(d);
      g=nan(Rep,1);
      gno= nan(Rep,1); 
      parfor or =1:Rep
            rng(or, 'twister') ;
             [Yb,Ya,~,~]  =   sim_data_master(Sf, Sb, meanb,scale,N,kn, day,  tau,missingj,disp_red)  ; 
              [Ka,Kb,Kmix] = selectK_data(Ya, Yb,1);
                 [mix,nomix] = bootstrap_qe(Ya,Yb,DAYS(d), Ka,Kb, Kmix, Kmix, B) ; 
                    g(or) = mix(3) ; 
                      gno(or) = nomix(3); 

                        %%   null histogram plots 
              if day ==5 && disp_red==1
                     tstat(or) = mix(2);
                      IQR(or) = mix(4); 
                
                      tstat_nomix(or) = nomix(2);
                      IQR_nomix(or) = nomix(4); 
 

              end % null plot 


      end % or 
  rejection_mix(d,:)= g';
   rejection_nomix(d,:)=  gno' ; 
end % d 

table1= mean(rejection_mix ,2)' ;   % 1 by day , table 1
table2= mean(rejection_nomix,2)' ;   % 1 by day ,  table 2

 if disp_red==1
      zstat= tstat./IQR ;
        zstat_nomix= tstat_nomix./IQR_nomix ;

 else 
      zstat=nan(Rep, 1) ;
       zstat_nomix=nan(Rep, 1) ;
 end 



 
 