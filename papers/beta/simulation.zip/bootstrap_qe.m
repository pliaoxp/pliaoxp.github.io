function [mix,nomix] = bootstrap_qe(Ya,Yb, DAYS, Ka,Kb, Kamix, Kbmix, B)

rng(1000); % fix seed

% cs bootstrap 

% B = num bootstraps

% output:  mix:  |P- P|^2 -bias  - (|P mix -P mix|^2 - bias) the proposed method with mix statistic
%          nomix: |P- P|^2 -bias the method without mix statistic, as a comparison. 


% mix(1)=  pvalue, 
% mix(2) = the test statistic, without standard error scaling
% mix(3) = mix(2)> critical value, ==1 means reject, ==0 means accept
% mix(4) = IQR, used for scaling to get pivotal statistic 
 
         
       
      
   [N,T]=size(Ya);
       
       %% estimate
       
       [diffP,  diffPmix,bias,biasmix] = statis_mix(Ya,Yb, DAYS, Ka,Kb, Kamix,Kbmix);
           d1 = diffP - bias ;
           d2 = diffPmix - biasmix ;
      
       tstat_mix   = d1 - d2;
       tstat_nomix = d1; 
      
 
                 
      %% cs bootstrap
          tstatboot_mix=nan(B,1);  
          tstatboot_nomix=nan(B,1); 
        for b=1:B
              ind= randsample(N,N,1);
              Yaboot= Ya(ind,:);
              Ybboot=Yb(ind,:); 
              
           [diffP1,  diffPmix1,bias1,biasmix1] = statis_mix(Yaboot,Ybboot, DAYS, Ka,Kb, Kamix,Kbmix);
  
                     d1=  diffP1 -bias1 ;
                   d2=  diffPmix1-biasmix1; 
                         
               tstatboot_mix(b) =  d1- d2 ;
               tstatboot_nomix(b) =  d1 ;
            
        end  % b 

        %% use mix 
        mix = nan(1,4);
       
        
         zboot =  tstatboot_mix-tstat_mix ;
         tau=quantile(zboot,0.95);
         pvalue_mix =mean(zboot>tstat_mix) ;
       
          IQR_mix= (quantile(zboot, 0.75) - quantile(zboot, 0.25) )/ 1.349;

           mix(1) =  pvalue_mix ;
           mix(2) = tstat_mix ; % test statistic
           mix(3) = tstat_mix >tau; % reject 
           mix(4) = IQR_mix;
      
        %% no mix 
          nomix = nan(1,4); 
         zboot =  tstatboot_nomix-tstat_nomix ;
        
         tau=quantile(zboot,0.95);
         pvalue_nomix =mean(zboot>tstat_nomix) ;
       

          IQR_nomix= (quantile(zboot, 0.75) - quantile(zboot, 0.25) )/ 1.349;
   

           nomix(1) =  pvalue_nomix ;
           nomix(2) =  tstat_nomix ; % test statistic
           nomix(3) = tstat_nomix >tau; % reject 
           nomix(4) = IQR_nomix;


end
  


