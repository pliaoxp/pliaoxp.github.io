

clear all

%% generate simulated data  for one month (20 days)

Ydata = load('sample_data.dat');  
Ya=  Ydata(1:500,:);  % morning return data of 500 stocks
Yb = Ydata(501:end,:);    % after return data of 500 stocks
day = 20; 

%% analysis , using p-value

   B=1000; % bootstrap sample

  [Ka,Kb,Kmix] = selectK_data(Ya, Yb,1);
  [mix,~] = bootstrap_qe(Ya,Yb, day, Ka,Kb, Kmix, Kmix, B);
  pvalue  =  mix(1); 
 
