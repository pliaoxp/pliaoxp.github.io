% master file 

clear 

%num_Rep = [2000, 500];   % num_Rep(1) = replication for the null; %num_Rep(2) = replication for alternatives
 num_Rep = [50, 50]; 


tic
% 40 core CPU:  num_Rep = [2000, 500]  in total (8000 reps) take  40 hours 
% 8 core CPU:   num_Rep = [50, 50]   in total (500 reps) take 20 hours 
 

%% H0 , kn =12 
disp_red= 1 ;  % 1= null 

Rep= num_Rep(1)    ;  % MC, 2000 for null
 
kn= 12 ;   % sampling frequency, 12 = 10 min 
[table1, table2,  zstat,  zstat_nomix] =  allresults(kn,Rep,[], [], disp_red) ; 
% table1 reproduces the row of "H0, kn= 12" in table 1 of the paper 
% table2 reproduces the row of "H0, kn= 12" in table 2 of the paper  

%% H0  null histogram plot , reproducing Figure 2
  if disp_red==1

      
      x=[-3:0.1:3];
    y=normpdf(x);   
    for k=1:2 % subplot 
        switch k
            case 1 
                z=zstat;
                h=     '$k_n\sqrt{p}(\widehat{\mathcal A}- \widehat{\mathcal A}_{mix})/\sigma^*$';
            case 2
                 z=zstat_nomix;
                    h=     '$k_n\sqrt{p}\widehat{\mathcal A}/\sigma^*$';
        end
        subplot(1,2,k)
        histogram(z,'Normalization', 'pdf'); 
        set(gca,'fontsize',18)
        t= set( title(h),'Interpreter','Latex');
         t.FontSize = 16;
        hold on;
        plot(x,y,'LineWidth',3); 
        hold off;
        
      end % subplot  k 

  end % disp_red==1 for histogram plot 
    
%% H0 , kn = 24
disp_red= 1 ;  % 1= null 

kn= 24 ;   % sampling frequency,   24= 5 min
[table1z, table2z, ~, ~] = allresults(kn,Rep,[], [], disp_red) ; 
% table1z reproduces the row of "H0, kn= 24" in table 1 of the paper 
% table2z reproduces the row of "H0, kn= 24" in table 2 of the paper  

display("H0, kn=24")
%% A1 
disp_red= 2 ; %  2= "one beta diff "  alternative 
Rep= num_Rep(2)  ;  

 kn= 12 ;   % sampling frequency, 12 = 10 min 
 tau = 1/100; 
[A1table1, A1table2,  ~, ~] =  allresults(kn,Rep,tau, [], disp_red); 
% A1table1 reproduces the row of "A1 \tau = 0.01, kn= 12" in table 1 of the paper 
% A1table2 reproduces the row of "A1 \tau = 0.01, kn= 12" in table 2 of the paper  

 kn= 12 ;   % sampling frequency, 12 = 10 min 
 tau = 5/100; 
[A1table1z, A1table2z,  ~, ~] = allresults(kn,Rep,tau, [], disp_red);  
% A1table1z reproduces the row of "A1 \tau = 0.05, kn= 12" in table 1 of the paper 
% A1table2z reproduces the row of "A1 \tau = 0.05, kn= 12" in table 2 of the paper  

 kn= 24 ;   % sampling frequency, 12 = 10 min 
 tau = 1/100; 
[A1table1b, A1table2b,  ~, ~] =  allresults(kn,Rep,tau, [], disp_red); 
% A1table1b reproduces the row of "A1 \tau = 0.01, kn= 24" in table 1 of the paper 
% A1table2b reproduces the row of "A1 \tau = 0.01, kn= 24" in table 2 of the paper  

 kn= 24 ;   % sampling frequency, 12 = 10 min 
 tau = 5/100; 
[A1table1zb, A1table2zb,  ~, ~] = allresults(kn,Rep,tau, [], disp_red);  
% A1table1zb reproduces the row of "A1 \tau = 0.05, kn= 24" in table 1 of the paper 
% A1table2zb reproduces the row of "A1 \tau = 0.05, kn= 24" in table 2 of the paper  

display("A1 done")

%% A2
disp_red= 3 ; %    3= "one beta missing"   alternative
Rep= num_Rep(2) ;  

 kn= 12 ;   % sampling frequency, 12 = 10 min 
missingj = 2 ; 
[A2table1, A2table2,  ~, ~]= allresults(kn,Rep,[], missingj, disp_red) ; 
% A2table1 reproduces the row of "A2 beta(2)=0, kn= 12" in table 1 of the paper 
% A2table2 reproduces the row of "A2 beta(2)=0, kn= 12" in table 2 of the paper  

 kn= 12 ;   % sampling frequency, 12 = 10 min 
missingj = 3 ; 
[A2table1z, A2table2z,  ~, ~]= allresults(kn,Rep,[], missingj, disp_red) ; 
% A2table1z reproduces the row of "A2 beta(3)=0, kn= 12" in table 1 of the paper 
% A2table2z reproduces the row of "A2 beta(3)=0, kn= 12" in table 2 of the paper  

display("A2 kn=12 done")

 kn= 24 ;   % sampling frequency, 12 = 10 min 
missingj = 2 ; 
[A2table1b, A2table2b,  ~, ~]= allresults(kn,Rep,[], missingj, disp_red) ; 
% A2table1b reproduces the row of "A2 beta(2)=0, kn= 24" in table 1 of the paper 
% A2table2b reproduces the row of "A2 beta(2)=0, kn= 24" in table 2 of the paper  

 kn= 24 ;   % sampling frequency, 12 = 10 min 
missingj = 3 ; 
[A2table1zb, A2table2zb,  ~, ~]= allresults(kn,Rep,[], missingj, disp_red) ; 
% A2table1zb reproduces the row of "A2 beta(3)=0, kn= 24" in table 1 of the paper 
% A2table2zb reproduces the row of "A2 beta(3)=0, kn= 24" in table 2 of the paper  

%%  reproducing Table 1 

table1kn12= [table1;A1table1;A1table1z ;A2table1 ; A2table1z  ];
table1kn24= [table1z;A1table1b; A1table1zb ; A2table1b ; A2table1zb];
table1= [table1kn12;table1kn24 ] ;

%%  reproducing Table  2 


table2kn12= [table2; A1table2; A1table2z;  A2table2;  A2table2z ]  ;
table2kn24= [ table2z ;  A1table2b ; A1table2zb ;  A2table2b ; A2table2zb] ;
table2 = [table2kn12;table2kn24 ]  ;

%% outputs:

table1
table2

% also the output plot for Figure 2

toc 