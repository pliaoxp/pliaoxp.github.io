function Khat=selectK_BN(Y,Kmax)

 
%%  outputs: 6 estimated number of factors from Bai and Ng (2002)
% K max: maximum number of candidates, e.g., 7~10

K=nan(6,1);  % 6 different criterion
[N,T]=size(Y);

  S= Y'*Y/(N*T); % T by T
  Cnt= min(sqrt(N),sqrt(T));
  %% PC criterion
  
    [u,Q]= eigs(S, Kmax);
     Ds= sqrt(N*T*Q);
    v=Y*u*inv(Ds);
    hbeta=v*sqrt(N)  ;  % N by N eigenvector
    factor= Y'*hbeta/N;
    error=  Y- hbeta*factor';
sigma2=    norm(error,'fro')^2/(N*T); % 

values=diag(Q);
values=sort(values,'descend');  % top eigenvalues 
 cumvalues= cumsum(values);
 pen1=(N+T)/(N*T)*log(N*T/(N+T));
 pen2= (N+T)/(N*T)*log(Cnt^2);
 pen3=log(Cnt^2)/(Cnt^2);
 
 pc1 = cumvalues -pen1*sigma2*[1:Kmax]';
 pc2 = cumvalues -pen2*sigma2*[1:Kmax]';
 pc3 = cumvalues -pen3*sigma2*[1:Kmax]';
 [~,K(1)]=max(pc1);
 [~,K(2)]=max(pc2);
 [~,K(3)]=max(pc3);
 
 %% IC criterion
 [~,Qtotal]= eig(S); 
    V=  trace(Qtotal) - cumvalues; 
    ic1= log(V) +pen1*[1:Kmax]';
    ic2= log(V) +pen2*[1:Kmax]';
    ic3= log(V) +pen3*[1:Kmax]';
    [~,K(4)]=min(ic1);
    [~,K(5)]=min(ic2);
    [~,K(6)]=min(ic3);
    
    Khat= K;
    
end
    