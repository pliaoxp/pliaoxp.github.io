function [Ka, Kb, Kmix]= selectK_data(Ya,Yb,stan)


% stan = 1: standardize,   = 0: no standarize 

  Yamix =  [Ya(:,[1:2:end]) Yb(:,[1:2:end])] ;  % odd
  Ybmix =  [Ya(:,[2:2:end]) Yb(:,[2:2:end])];   % even
  
  [N,T]=size(Ya);
  if stan== 1 % for each stock, standardize it 
      sa = std(Ya, 0,2)*ones(1,T);
      sb = std(Yb, 0,2)*ones(1,T);
      ya= Ya./sa;
      yb= Yb./sb;
      
      sa = std(Yamix, 0,2)*ones(1,T);
      sb = std(Ybmix, 0,2)*ones(1,T);
      Z1= Yamix./sa;
      Z2= Ybmix./sb;
  else % no standardize
      ya= Ya;
      yb= Yb;
      Z1= Yamix;
      Z2= Ybmix; 
  end
  % get Ka Kb initial 
    Khat=selectK_BN(ya,10);
    Ka = Khat(5); 
    Khat=selectK_BN(yb,10); 
    Kb = Khat(5); 
      
    % get Kmix 
     Khat=selectK_BN(Z1,10); 
     Kmix_1 = Khat(5);    
     Khat=selectK_BN(Z2,10);   
     Kmix_2 = Khat(5);  
       
     % final
     Ka = min([Ka, Kmix_1,Kmix_2]);   
     Kb = min([Kb, Kmix_1,Kmix_2]);   
     Kmix = min(Kmix_1,Kmix_2);  
       