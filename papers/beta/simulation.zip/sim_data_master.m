function [Yb,Ya,truebetaa,truebetab]=sim_data_master(Sf, Sb, meanb,scale,N,kn,DAYS,  tau,missingj,disp_red)


if kn== 12
    n=40;
elseif kn==24
    n= 80;
end

K=size(Sf,1); 
%N is number of assets, K is number of factors, n is number of HF
%increments per day, kn is number of increments in a window, DAYS is number of days
%disp_red is:
%  1 = null
%  2 = alternative that first beta is different
%  3 = alternative that third component of betaa is off. so betab= (betaa, g)

%par setting
kappa = 8.3; theta = 1; sigma = 1;

  su= unifrnd(0.5,1.5,N,1) *scale;
Sfhalf= Sf^(1/2); Sbhalf= Sb^(1/2); Siguhalf=diag(su);


%% simulate stoch vol
s2 = zeros(DAYS*n,1); s2(1) = theta;
for i=2:DAYS*length(s2)
    s2(i) = s2(i-1)+kappa*(theta-s2(i-1))/(252*n) + sqrt(max(s2(i-1),0))*sigma*randn(1)/sqrt(252*n);
end
 
s2_b = zeros(DAYS*kn,1); s2_a = zeros(DAYS*kn,1);
for t=1:DAYS
    s2_b((t-1)*kn+1:t*kn) = s2((t-1)*n+1:(t-1)*n+kn);
    s2_a((t-1)*kn+1:t*kn) = s2(t*n-kn+1:t*n);
end

%% simulate beta

 truebetab = randn(N,K)*Sbhalf+meanb'; 
 truebetaa = truebetab;

 switch disp_red
        case 1  % null 
            truebetaa  =   truebetab ;
        case 2 % alternative, just different loadings
            %  tau = |betaa-betab|^2/|betab|^2, and 0.05 
            rate= sqrt( tau/N)*norm(truebetab,'fro');
            truebetaa(:,1) = truebetab(:,1)  + rate * randn(N,1) ;  
        case 3 % alternative, one of betaa is off
            % missingj = 2 or 3 
            truebetaa(:,missingj)=zeros(N,1);
  end




%% simulate returns



trueFb = randn(DAYS*kn,K) *Sfhalf/sqrt(252*n); 
trueUb =  Siguhalf* randn(N,DAYS*kn)/sqrt(252*n); 
Yb=(truebetab*trueFb' +trueUb)*diag(sqrt(s2_b));

trueFa = randn(DAYS*kn,K) *Sfhalf/sqrt(252*n); 
trueUa =  Siguhalf* randn(N,DAYS*kn)/sqrt(252*n); 
Ya=(truebetaa*trueFa' +trueUa)*diag(sqrt(s2_a));

 