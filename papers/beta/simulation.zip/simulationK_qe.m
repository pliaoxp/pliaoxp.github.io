
% select number of factor simulation
 
 clear ;
N= 500;
 
Rep= 100 ;  % MC, 100

 
 %% start simulation
 

 

Sf=   1.0e-05 *[ 0.1198   0   0
   -0.0000    0.0377   0
   0   0    0.0264];

Sb= [0.2326   -0.2474    0.2603
   -0.2474    0.9224    0.0837
    0.2603    0.0837    0.9139];
meanb=[ -0.8763
   -0.2818
    0.2965];
scale = 0.0011; 
 


 DAYS= [1,5,10,15,20, 30];
 
Ka12=nan(3,length(DAYS), Rep);
Kb12=nan(3,length(DAYS), Rep);
 Kmix12=nan(3,length(DAYS), Rep);


Ka24=nan(3,length(DAYS), Rep);
Kb24=nan(3,length(DAYS), Rep);
 Kmix24=nan(3,length(DAYS), Rep);


 parfor or =1 :Rep
     rng(or, 'twister') ;
      Ga12= nan(3,length(DAYS));
       Gb12= nan(3,length(DAYS));
       Gmix12= nan(3,length(DAYS));
       Ga24= nan(3,length(DAYS));
       Gb24= nan(3,length(DAYS));
       Gmix24= nan(3,length(DAYS));

     for disp_red =1:3  % hypotheses
         switch disp_red
             case 1 
                 tau=[];
                 missingj=[];
             case 2 
                  tau = 5/100; 
                   missingj=[];
             case 3
                 tau=[];
                 missingj = 3;
         end % switch 
        for d =1:length(DAYS)
             kn=12;
            [Yb,Ya,~,~]=  sim_data_master(Sf, Sb, meanb,scale,N,kn, DAYS(d),  tau,missingj,disp_red)     ;
            [Ga12(disp_red,d), Gb12(disp_red,d), Gmix12(disp_red,d)]= selectK_data(Ya,Yb,1) ; % standdize

             kn=24  ;
            [Yb,Ya,~,~]= sim_data_master(Sf, Sb, meanb,scale,N,kn, DAYS(d),  tau,missingj,disp_red)     ;
            [Ga24(disp_red,d), Gb24(disp_red,d), Gmix24(disp_red,d)]= selectK_data(Ya,Yb,1) ; % standdize

  

        end % d
     end % disp_red
        
      Ka12(:,:,or)=Ga12;
        Kb12(:,:,or)=Gb12;
        Kmix12(:,:,or)=Gmix12;

        Ka24(:,:,or)=Ga24;
        Kb24(:,:,or)=Gb24;
        Kmix24(:,:,or)=Gmix24;
        or
end % or
 
 

 x= [1:length(DAYS)];
 for k= 1:9
     subplot(3,3,k)
     switch k
         case  1 % Ka null
             meanK=[mean(Ka12(1,:,:),3);  mean(Ka24(1,:,:),3)];
             b= bar(x,meanK);
          [t,s] =     title('null Ka =3');
         case 2  % Kb null
             meanK=[mean(Kb12(1,:,:),3);  mean(Kb24(1,:,:),3)];
                b= bar(x,meanK);
           [t,s] =     title('null Kb=3');
         case 3  % Kmix null
             meanK=[mean(Kmix12(1,:,:),3);  mean(Kmix24(1,:,:),3)];
               b= bar(x,meanK);
          [t,s] =    title('null Kmix =3 ');
             
             case 4 % alternative 
             meanK=[mean(Ka12(2,:,:),3);  mean(Ka24(2,:,:),3)];
             b= bar(x,meanK);
          [t,s] =     title('alternative A_1 Ka =3');
         case 5  %  
             meanK=[mean(Kb12(2,:,:),3);  mean(Kb24(2,:,:),3)];
                b= bar(x,meanK);
          [t,s] =      title('alternative A_1 Kb=3');
         case 6 %  
             meanK=[mean(Kmix12(2,:,:),3);  mean(Kmix24(2,:,:),3)];
               b= bar(x,meanK);
          [t,s] =    title('alternative A_1 Kmix =4 ')
             
       case 7  % Ka  
             meanK=[mean(Ka12(3,:,:),3);  mean(Ka24(3,:,:),3)];
             b= bar(x,meanK);
          [t,s] =     title('alternative A_2 Ka =2');
           xlabel('Days') 
         case 8  % Kb  
             meanK=[mean(Kb12(3,:,:),3);  mean(Kb24(3,:,:),3)];
                b= bar(x,meanK);
             [t,s] =   title('alternative A_2 Kb=3');
              xlabel('Days') 
         case 9 % Kmix 
             meanK=[mean(Kmix12(3,:,:),3);  mean(Kmix24(3,:,:),3)];
               b= bar(x,meanK);
          [t,s] =    title('alternative A_2 Kmix =3');
           xlabel('Days') 
     end% switch
  
     legend('kn=12','kn=24');
  
      xtips1 = b(1).XEndPoints;

    
    ytips1 = round(b(1).YEndPoints,1);
    labels1 = string(b(1).YData);
    text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',10);
    xtips2 = b(2).XEndPoints;
    ytips2 = b(2).YEndPoints;
    labels2 = string(b(2).YData);
    text(xtips2,ytips2,labels2,'HorizontalAlignment','center', 'VerticalAlignment','bottom','FontSize',10);
    
      xticklabels({'1','5','10','15','20','30'});
    ax = gca;
    ax.FontSize = 15;
  t.FontSize = 12;
 end % k 

     

 