  function  [diffP,  hFa,hFb, bias,  varuaadj, varubadj, Proja, Projb,  vau,vbu,se] = statis_ProjOutput(Ya,Yb, DAYS, Ka,Kb, biasornot,seornot)

% inputs: Ya: N by T of returns of period a, N = num firms, T= kn*DAYS
%         Yb: N by T of returns of period b, N = num firms, T= kn*DAYS
%         DAYS: number of days aggregated
%         Ka: num of factors estimated in period a
%         Kb: num of factors estimated in period b
%        

% output:  diffP = |Pa-Pb|^2
%         if biasornot ==1 , also compute bias, otherwise not compute bias
%         if seornot ==1 , also compute se, otherwise not compute se

%    varuaadj = Days by 1 idiosy var for a 
%    varubadj = Days by 1 idiosy var for b

 

    [N, T] = size(Ya);
    kn = T/DAYS;  % numb of observations each day


    S= Ya'*Ya/(N*T); % T by T
    [u,Qa]= eigs(S, Ka);
    Ds= sqrt(N*T*Qa);
    v=Ya*u*inv(Ds);
    hbetaa=v*sqrt(N)  ;  % N by N eigenvector
    factora= Ya'*hbetaa/N;
    ua=  Ya- hbetaa*factora';
     Pa= hbetaa*inv(hbetaa'*hbetaa)*hbetaa';
     
     Proja= Pa;
     
    S= Yb'*Yb/(N*T); % T by T
    [u,Qb]= eigs(S, Kb);
    Ds= sqrt(N*T*Qb);
    v=Yb*u*inv(Ds);
    hbetab=v*sqrt(N)  ;  % N by N eigenvector
    factorb= Yb'*hbetab/N;
    ub=  Yb- hbetab*factorb';
    Pb= hbetab*inv(hbetab'*hbetab)*hbetab';
    
    Projb= Pb; 

    diffP=norm(Pa-Pb,'fro')^2;

    G=(2*hbetab'*hbetaa/N);
    hFa=factora*inv(Qa);
    hFb=factorb*inv(Qb);
    
   

    %% bias 
    vau=nan(N,T);
    vbu=nan(N,T);
  if biasornot ==1 
     Baadj =nan(DAYS,1); Bbadj=nan(DAYS,1);
     DTa=eye(T); DTb= eye(T);
     for day = 1:DAYS
         interval=(day-1)*kn+1:day*kn;
          uaday=ua(:,interval); ubday=ub(:,interval);
         varuaday=  norm(uaday,'fro')^2/(kn*N) ; %O_P(1)    %sum(var(ua,0,2)/N)  ;
        varubday=  norm(ubday,'fro')^2/(kn*N) ; %O_P(1)    %sum(var(ua,0,2)/N)  ;
        DTa(interval,interval)=eye(kn)*varuaday;
         DTb(interval,interval)=eye(kn)*varubday;
         
         vau(:,interval)=  mean(uaday.^2,2)*ones(1,kn); % N by kn 
          vbu(:,interval)= mean(ubday.^2,2)*ones(1,kn) ;% N by kn 
     end
     varFUa= factora'*DTa*factora/T; 
     varFUb= factorb'*DTb*factorb/T;  
     varuaadj=nan(DAYS,1);    varubadj=nan(DAYS,1); 
    for  day =1:DAYS
        interval=(day-1)*kn+1:day*kn;
        uaday=ua(:,interval); ubday=ub(:,interval);
        hFaday=hFa(interval,:); hFbday=hFb(interval,:);
        factoraday=factora(interval,:); factorbday=factorb(interval,:);
        varuaday=  norm(uaday,'fro')^2/(kn*N) ; %O_P(1)    %sum(var(ua,0,2)/N)  ;
        varubday=  norm(ubday,'fro')^2/(kn*N) ; %O_P(1)    %sum(var(ua,0,2)/N)  ;

        % bias adjust  for a
        
        
        m=factoraday'*factoraday*inv(Qa)/kn ;
        delta1= trace(varFUa*inv(Qa)*m);
        delta2= -2*trace(m)*varuaday;
         Da=diag(diag(uaday*uaday'/kn));
        Upsilona = 1/N*hbetaa'*Da*hbetaa;
        theta2=trace(Upsilona);
        delta3= -theta2;
        deltaa= (delta1+delta2)/T+delta3/N;
        varuaadj(day)=  varuaday - deltaa ;
    
        % bias adjust  for b
        m=factorbday'*factorbday*inv(Qb)/kn ;
         delta1= trace(varFUb*inv(Qb)*m);
        delta2= -2*trace(m)*varubday;
           Db=diag(diag(ubday*ubday'/kn));
        Upsilonb = 1/N*hbetab'*Db*hbetab;
       theta2=trace(Upsilonb);
          delta3= -theta2;
        deltab= (delta1+delta2)/T+delta3/N;
        varubadj(day)=  varubday - deltab ;
     
        Baadj(day)=2*trace(hFaday'* hFaday/kn)*  varuaadj(day)  ;  %O(1)
        Bbadj(day)=2*trace(hFbday'* hFbday/kn)*   varubadj(day) ;  %O(1)
    end % day

     bias=mean(Baadj)/T+mean(Bbadj)/T;

  else %   biasornot == 0 
      bias=nan;
       varuaadj=nan;
       varubadj=nan;
        vau=nan;
        vbu=nan;
      
  end  % if biasornot ==1 
  
   if seornot ==1
          Sia=nan(N,1); Sib= nan(N,1); Siab=nan(N,1);
        for i=1:N
            fai=hFa'*diag(ua(i,:).^2)*hFa/T;
            fbi=hFb'*diag(ub(i,:).^2)*hFb/T;
            Sia(i)= norm( fai , 'fro')^2;
            Sib(i)= norm(fbi  , 'fro')^2;
            Siab(i)= trace(fai*G'*fbi*G);
        end % for i
        Vahat= mean(Sia)*2 *4 ; 
        Vbhat= mean(Sib)*2 *4 ; 
        Vabhat= mean(Siab) *4 ; 
        se = sqrt(Vahat+Vbhat+Vabhat)  ; % O_P(1)
     else se = nan;
   end %  if seornot ==1
     

end


