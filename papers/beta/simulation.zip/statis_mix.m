  function  [diffP,  diffPmix,bias,biasmix] = statis_mix(Ya,Yb, DAYS, Ka,Kb, Kamix,Kbmix)

  % compute diffP = |P-P|^2 , bias of diffP
   %        diffPmix= |Pmixodd- Pmixeven|^2, bias of diffPmix
    
   [N,T]=size(Ya);
   kn= T/DAYS;
    Yamix =  [Ya(:,[1:2:end]) Yb(:,[1:2:end])] ;  % odd
    Ybmix =  [Ya(:,[2:2:end]) Yb(:,[2:2:end])];   % even
    [diffP,  ~,~, bias, varuaadj, varubadj, ~, ~, ~,~,~] = statis_ProjOutput(Ya,Yb, DAYS, Ka,Kb, 1,0);
    [diffPmix, hFodd,hFeven,~,~,~, ~, ~, ~,~,~] = statis_ProjOutput(Yamix,Ybmix, DAYS, Kamix,Kbmix,0,0); 
 
       
    
    %% compute bias for Pmix
    t= round(T/2);
    hFodda= hFodd(1:t,:);
    hFoddb= hFodd(t+1:T,:);
    hFevena=hFeven(1:t,:);
    hFevenb=hFeven(t+1:T,:);
    bodd=nan(DAYS,1); beven=nan(DAYS,1);
   for day = 1:DAYS
       knhalf= round(kn/2);
     interval=(day-1)*knhalf+1:day*knhalf;
     hFoddaday=hFodda(interval,:);
     hFoddbday=hFoddb(interval,:);
     hFevenaday=hFevena(interval,:);
     hFevenbday=hFevenb(interval,:);

     bo=(hFoddaday'*hFoddaday*varuaadj(day)+hFoddbday'*hFoddbday* varubadj(day))/kn;
     be=(hFevenaday'*hFevenaday*varuaadj(day)+hFevenbday'*hFevenbday* varubadj(day))/kn;
    bodd(day) =trace(bo);
    beven(day)= trace(be);

   end
       Bmixodd=2*mean(bodd)/T;
       Bmixeven= 2*mean(beven)/T;
       biasmix= Bmixodd+ Bmixeven;


          
  
  end