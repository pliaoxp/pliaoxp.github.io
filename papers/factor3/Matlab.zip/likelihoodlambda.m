function f=likelihoodlambda(Sy,Sigmau,Lambda)

% f=log|(LL'+Sigmau)|/N+tr(Sy(LL'+Sigmau)^{-1})/N

A=Lambda*Lambda'+Sigmau;
f1=log(abs(det(A)));
f2=trace(Sy*inv(A));
f=f1+f2;
f=f/length(Sy(1,:));