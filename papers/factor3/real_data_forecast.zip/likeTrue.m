function f=likeTrue(Sy,P,Sigmau,Lambda,lambda,F)

% f=log|(LL'+Sigmau)|/N+tr(Sy(LL'+Sigmau)^{-1})/N+ penalty

[T,r]=size(F);
M=F'*F/T;
A=Lambda*M*Lambda'+Sigmau;

f1=log(abs(det(A)));
f2=trace(Sy/A);
f3=0;

B=Sigmau.*P;
for i=1:length(B(1,:))
    f3=f3+norm(B(i,:),1)*lambda;
end;



f=f1+f2+f3;
f=f/length(Sy(1,:));