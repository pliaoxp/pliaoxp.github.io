clear;

% THIS code gives real data out-of-sample forecast result, in the new
% revised version, 
% multi lag included

% The tuning parameter is obtained using 5 fold CV.

 
%% load data

load lndata
series=[];
rawdata=[];
tcode=[];
thr=6;
N=cols(macrodat);
dates=(59+1/12:1/12:108)';
data=trimr(macrodat,12,0);
dates=trimr(dates,12,0);
for i=1:N;
  dum=data(:,i);
  m=mean(dum);
  if isnan(m) ==0;
      rawdata=[rawdata dum];
  series=str2mat(series,headertext{1,i});
  tcode=[tcode; vartype(i)];
  else
    disp([i m]);
  end;
end; 
series=trimr(series,1,0);
y=[];
N=cols(rawdata);
for i=1:N;
  if tcode(i)==0; tcode(i)=1; end; 
dum=transx(rawdata(:,i),tcode(i));
y=[y dum];
end;
y=y(49:end,:); % Data 1964.1 - 2007.12
 [ehat_T,Fhat_T,lamhat_T,ve2_T]=pc_T(standard(y),8);
y=standard(y)';  % y is N by TT
N=131;
TT=528;
T=round(0.8*TT);
  k=6;  % IP:total
     kk=114; % CPI: all
    %k=2; % % PI less transfers
    %k=4;  %  M & T sales
    %k=33; % Employ: total

%% setup r, T and lag
lag=3; 
r=8; % number of factors
h=12; %12   period ahead forecast

lambdarange= [0.01:0.03:0.3];
K=5 ; % fold cross validation
for cv=1:K
    cvvalidation(cv,:)=zeros(1,T);
    for t=1:round(T/K)
        cvvalidation(cv,cv+(t-1)*K)=1;
    end;
    cvvalidation_index(cv,:)=(cvvalidation(cv,:)==ones(1,T));
    cvtraining_index(cv,:)=(cvvalidation(cv,:)==zeros(1,T));

end;    

for s=1:TT-h+1
    Z(:,s)=mean(y(:,s:s+h-1),2);  % x_{t+h}^h
end;
 
for i=1:TT-T-h+1
    tic
    % known data
    Y=y(:,i:i+T-1); %N by T
    xIP=Z(k,i:i+T-h)';
    xnewIP=Z(k,T+i);
    
 
      xCPI=Z(kk,i:i+T-h)';
    xnewCPI=Z(kk,T+i);
    %{
     XPI=Y(2,:)';
    xPI=XPI(1:T);
    xnewPI=y(2,i+T);
    
     XMT=Y(4,:)';
    xMT=XMT(1:T);
    xnewMT=y(4,i+T);
    
    XE=Y(33,:)';
    xE=XE(1:T);
    xnewE=y(33,i+T);
   %}

%% find factors
    
%%%% PC
 [FPCA,LPCA]=factor(Y,eye(N),r);
    
     %%%%%%% calculate error from PCA
    u=Y-LPCA*FPCA';
    Su=u*u'/(T-4);
      Phi= diag(diag(Su));
 
      IPerrorPCA(i)=FEmultiLag(xIP,xnewIP, FPCA,Y,h,k,lag);
      CPIerrorPCA(i)=FEmultiLag(xCPI,xnewCPI, FPCA,Y,h,kk,lag);
      %PIerrorPCA(i)=forecasterror(xPI,xnewPI, FPCA);
      %MTerrorPCA(i)=forecasterror(xMT,xnewMT, FPCA);
      %EerrorPCA(i)=forecasterror(xE,xnewE, FPCA);
      
      
    %% Diagonal ML, Bai and Li (2012)
    
 
    Sy=Y*Y'/T;
    Lambda0=ones(N,r)*10;
    Lambda=LPCA;
    FDML=FPCA;
    Sigma1=diag(diag(Su));
    
    %{
    Sigmaold=eye(N)*100;
    Fini=ones(T,r);
   
    while likelambda(Sy,Sigmaold,Lambda0,Fini)-likelambda(Sy,Sigma1,Lambda,FDML)>10^(-7)
        Sigmaold=Sigma1; 
        Lambda0=Lambda;  % old
        Fini=FDML;
        A=inv(Lambda0*Lambda0'+Sigma1);
        C=Sy*A*Lambda0;
        Eff=eye(r)-Lambda0'*A*Lambda0+Lambda0'*A*C;
        Lambda=C/Eff;  % N x r
        M=Sy-Lambda*Lambda0'*A*Sy;  % Sy-C'
        Sigma1=diag(diag(M));
        LDML=Lambda;
        FDML= (inv(LDML'*(Sigma1\LDML))*LDML'*(Sigma1\Y))';  % T by r
    end;
 
     IPerrorDML(i)=FEmultiLag(xIP,xnewIP, FDML,Y,h,k,lag);
      CPIerrorDML(i)=FEmultiLag(xCPI,xnewCPI, FDML,Y,h,kk,lag);
   %  PIerrorDML(i)=forecasterror(xPI,xnewPI, FDML);
    %  MTerrorDML(i)=forecasterror(xMT,xnewMT, FDML);
     %  EerrorDML(i)=forecasterror(xE,xnewE, FDML);
 %}
     Sdml=Sigma1;
    
     
        %% ML Bai and Liao   cross validation finding the best tuning
        K=5;
     gamma=5;  t=0.1;
        
   for l=1: length(lambdarange)
       lambda=lambdarange(l); % mu, was 0.2
       
       for cv=1:K
           tY=Y(:,cvtraining_index(cv,:));
           vY=Y(:,cvvalidation_index(cv,:));
           tSy=tY*tY'/length(tY(1,:));
           vSy=vY*vY'/length(vY(1,:));
           Sigmaold=Sdml;
           Lambda0=LPCA;
           Factor0=FPCA(cvtraining_index(cv,:),:);
           H=Lambda0*Lambda0'+Sigmaold;
           C=tSy*(H\Lambda0);
           Eff=eye(r)-Lambda0'*(H\Lambda0)+Lambda0'*(H\C);
           Lambda=C/Eff;
           Su=tSy-C*Lambda'-Lambda*C'+Lambda*Eff*Lambda';
           KML=Sigmaold-t*(inv(Sigmaold)-(Sigmaold\Su)*inv(Sigmaold));
            P=Pmatrix(Su,gamma);
           B=lambda*t*P;
           Sigma1cv= wthresh(KML,'s',B);
           LMLcv=Lambda;
          FMLcv= (inv(Lambda'*(Sigma1cv\Lambda))*Lambda'*(Sigma1\tY))';
           while  likeTrue(tSy,P,Sigmaold,Lambda0,lambda,Factor0)- likeTrue(tSy,P,Sigma1cv,Lambda,lambda, FMLcv)>10^(-7)
 
                Sigmaold=Sigma1cv;
                Lambda0=Lambda;  % old
                Factor0=FMLcv;
                H=Lambda0*Lambda0'+Sigmaold;
                C=tSy*(H\Lambda0);
                Eff=eye(r)-Lambda0'*(H\Lambda0)+Lambda0'*(H\C);
                Lambda=C/Eff;
                Su=tSy-C*Lambda'-Lambda*C'+Lambda*Eff*Lambda';
                KML=Sigmaold-t*(inv(Sigmaold)-(Sigmaold\Su)*inv(Sigmaold));
                %KML=Sigmaold-t*((Sigmaold\(Sigmaold-Su))/Sigmaold);
               % KML=Sigmaold-t*((H\(H-tSy))/H);
                P=Pmatrix(Su,gamma);
                B=lambda*t*P;
              %  Sigma1=soft(KML,B);
                Sigma1cv=wthresh(KML,'s',B);
                LMLcv=Lambda;
                FMLcv= (((LMLcv'*(Sigma1cv\LMLcv))\LMLcv')*(Sigma1cv\tY))';  % T by r
           end; % while
           A=LMLcv*LMLcv'+Sigma1cv;
           likelihood(cv)= log(abs(det(A)))/N+trace(vSy/A)/N;
            
           clear tY vY;
       end; % cv <=K
      cv_likelihood(l)=mean(likelihood);
       
       
       clear likelihood;
       
   end; % l =1...length(lambdarange)
   [aa, aaa] =min(cv_likelihood);
   lambda=lambdarange(aaa);
   % clear cv_likelihood;
        
        
     
    %% now using the best tuning
    
 
    gamma=5; t=0.1;
    Sigmaold=Sdml;
    Lambda0=LPCA;
    Factor0=FPCA;
    H=Lambda0*Lambda0'+Sigmaold;
    C=Sy*(H\Lambda0);
    Eff=eye(r)-Lambda0'*(H\Lambda0)+Lambda0'*(H\C);
    Lambda=C/Eff;
    Su=Sy-C*Lambda'-Lambda*C'+Lambda*Eff*Lambda';
   KML=Sigmaold-t*(inv(Sigmaold)-(Sigmaold\Su)*inv(Sigmaold));
    P=Pmatrix(Su,gamma);
    B=lambda*t*P;
      Sigma1= wthresh(KML,'s',B);
    FML= (inv(Lambda'*(Sigma1\Lambda))*Lambda'*(Sigma1\Y))'; 
    
     while  likeTrue(Sy,P,Sigmaold,Lambda0,lambda,Factor0)- likeTrue(Sy,P,Sigma1,Lambda,lambda, FML)>10^(-7)
        Sigmaold=Sigma1;
        Lambda0=Lambda;  % old
        Factor0=FML;
        H=Lambda0*Lambda0'+Sigmaold;
        C=Sy*(H\Lambda0);
        Eff=eye(r)-Lambda0'*(H\Lambda0)+Lambda0'*(H\C);
        Lambda=C/Eff;
        Su=Sy-C*Lambda'-Lambda*C'+Lambda*Eff*Lambda';
        KML=Sigmaold-t*(inv(Sigmaold)-(Sigmaold\Su)*inv(Sigmaold));
       % KML=Sigmaold-t*((Sigmaold\(Sigmaold-Su))/Sigmaold);
        %KML=Sigmaold-t*((H\(H-Sy))/H);
        P=Pmatrix(Su,gamma);
        B=lambda*t*P;
       % Sigma1=soft(KML,B);
       Sigma1=wthresh(KML,'s',B);
        LML=Lambda;
        FML= (inv(LML'*(Sigma1\LML))*LML'*(Sigma1\Y))';  % T by r
    end;
     
    
   
   
    

    
     
      IPerrorML(i)=FEmultiLag(xIP,xnewIP, FML,Y,h,k,lag);
       CPIerrorML(i)=FEmultiLag(xCPI,xnewCPI, FML,Y,h,kk,lag);
    %PIerrorML(i)=forecasterror(xPI,xnewPI, FML);
    % MTerrorML(i)=forecasterror(xMT,xnewMT, FML);
    %  EerrorML(i)=forecasterror(xE,xnewE, FML);
    
   
   
  i
  
  
  toc 
end;
 
 
    %mean(IPerrorPCA)/  mean(IPerrorPCA) % industrial production
    %mean(IPerrorDML)/  mean(IPerrorPCA)
     mean(  IPerrorML)/  mean(IPerrorPCA)

     %{
     i
     
     
 
    mean(CPIerrorPCA) % consumer industrial production
    mean(CPIerrorDML)
  mean(CPIerrorDOZ) 
    mean(CPIerrorEPC)
    mean(CPIerrorEPC2)
     mean(CPIerrorML)
     
     
      
     i
     
     
    mean(PIerrorPCA)
    mean(PIerrorDML)
  mean(PIerrorDOZ) 
    mean(PIerrorEPC)
     mean( PIerrorML)
     
        i
     
    mean(MTerrorPCA)
    mean(MTerrorDML)
  mean(MTerrorDOZ) 
    mean(MTerrorEPC)
     mean( MTerrorML)
     
     i
     
     
    mean(EerrorPCA)
    mean(EerrorDML)
  mean(EerrorDOZ) 
    mean(EerrorEPC)
     mean(EerrorML)
 %}
 