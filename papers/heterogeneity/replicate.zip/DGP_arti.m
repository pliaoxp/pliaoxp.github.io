
function  [Y,X,theta, interac_eff,sey] =  DGP_arti(N,T,K, K0, Kx,rho,homomodel , fixeffect, noise_ratioX)



% artificial DGP 

% X has a factor model
% theta has a factor model
% intera_eff has a factor model 

meanx1=  ones(N,1)*2;  
 
am=2; % 2
meang=am; % Eg_t
meanlambda=am; % E lambda_i
meanf=am; % Ef_t
meanalpha=am; % E alpha




 
    %% theta 
    a= randn(N,K(1))+meanlambda;
    L = sign(a).* min(abs(a),10) ;  % truncate so that loading is bounded  
    b= randn(K(1),T)+meanf; 
    F=  sign(b).* min(abs(b),10) ;  
  

     a= randn(N,K(2))+meanlambda;
    L2 = sign(a).* min(abs(a),10) ; 
    b=  randn(K(2),T)+meanf; % K by T 
    F2 = sign(b).* min(abs(b),10) ;  

   switch homomodel 
       case 'hetero'
          L= L ; L2= L2;
         F= F;   F2=F2; 
       case 'indivihomo'
           L= ones(N,1)*mean(L,1) ;
           L2= ones(N,1)*mean(L2,1) ;
           F= F;   F2=F2; 
       
       case 'timehomo'
           F = mean(F,2)*ones(1,T) ;
            F2 = mean(F2,2)*ones(1,T) ;
            L= L ; L2= L2;

       case 'homo'
            L= ones(N,1)*mean(L,1) ;
           L2= ones(N,1)*mean(L2,1) ;
           F = mean(F,2)*ones(1,T) ;
            F2 = mean(F2,2)*ones(1,T) ;

   end % switch 


theta= nan(N,T,2);
theta(:,:,1)=L *F;
theta(:,:,2) = L2*F2;



if strcmp(fixeffect, 'interactive')
 a= randn(N,K0)+meanalpha;
    l = sign(a).* min(abs(a),10) ;
     interac_eff= l*(randn(K0,T)+meang) ;
elseif strcmp(fixeffect, 'twoway')    
    interac_eff= meanalpha*randn(N,1)*ones(1,T) + ones(N,1)*randn(1,T)*meang;
end


 
    
    %% X 


Ex= zeros(N,T,2) ; 
X=zeros(N,T,2);
for r= 1:2

    a= randn(N,Kx(r)); 
    loading = sign(a).* min(abs(a),10) ;
    common= loading *randn(Kx(r),T); 

    XseX  =   sqrt(noise_ratioX(r) /(1-noise_ratioX(r)) *   mean(var(common,0,2)))  ;

    Ex(:,1,r) = zeros(N,1) ; 
     for t=2:T
         Ex(:,t,r) = rho *  Ex(:,t-1,r) + randn(N,1) * XseX ;
     end
   
    X(:,:,r)= common + meanx1*ones(1,T) +Ex(:,:,r)    ; 
end 


r=1 ; 
mean(var(Ex(:,:,r)  ,0,2) ) / mean(var(X(:,:,r),0,2) )  ;


%% Y 
 

 A0=  interac_eff;  
A = sum(X.*theta,3);
s= unifrnd(0.5,1.5,N,1); 
Se = diag(s)  ; 
sey = mean(s); 

 
 e=nan(N,T);
 e(:,1) =   randn(N,1)  ; 
 for t=2:T
     e(:,t)= rho* e(:,t-1) + randn(N,1) ;
 end 

Y= A  +A0 + Se *e; 

 

end 

  
