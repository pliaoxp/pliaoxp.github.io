%{

% used in the paper 
% state level , agregate counties to states

countyreal: indices for counties
lnemp_rest_both: log employment
lnemp_TOT: log total employment
lnMW: log minimum wage
lnpop: log population
nonmissing_rest_both: for check purpose, not very useful
period: time periods, from 25 to 90, so T = 66
quarter: as the name suggests
state_fips: the state FIPS (Federal Information Processing Standard) for the corresponding county
stperiod: not used
T: time periods
year1: year
%}

clear
 
 

 kx= 3 ;  
 K0=1  ; % interactive fixed effect, 

 Kx(1)=kx ; Kx(2)=3  ;  
K(1)= 2   ; K(2)= 2 ;  % % theta 
     Kx(3)=3  ;  K(3)=2;
 


   load('/Users/yliao13/Dropbox/Liao/liao shared/low rank Matrix regression/submitcode/minimum_wage_reg_1.mat');         
         load('/Users/yliao13/Dropbox/Liao/liao shared/low rank Matrix regression/submitcode/indexTcase5.mat');         

     
 
 indexT=indexTcase5;  % fix this random arrangement of the time period index 
 
 % missing countyreal:  9013, 17001
  ind=abs(countyreal-9013).*abs(countyreal-17001) >0; % non missing  counties
 nonmissing_lnemp_rest_both=lnemp_rest_both(ind);
  nonmissing_lnemp_TOT=lnemp_TOT(ind);
  nonmissing_lnMW= lnMW(ind);
  nonmissing_lnpop= lnpop(ind);
nonmissing_countyreal=countyreal(ind);
nonmissing_state_fips=state_fips(ind);



i=1; t=1;
for or=1: 90948  
    if or==1
        lnemp(i,t)= nonmissing_lnemp_rest_both(or);
        lnemTOT(i,t)= nonmissing_lnemp_TOT(or);
        lnmw(i,t)= nonmissing_lnMW(or);
        lnPop(i,t)= nonmissing_lnpop(or);
        statepp(i,t)=nonmissing_state_fips(or);
        countypp(i,t)=nonmissing_countyreal(or);
        t=t+1;
    else if  nonmissing_countyreal(or)==nonmissing_countyreal(or-1) % same county
        lnemp(i,t)= nonmissing_lnemp_rest_both(or);
        lnemTOT(i,t)= nonmissing_lnemp_TOT(or);
        lnmw(i,t)= nonmissing_lnMW(or);
        lnPop(i,t)= nonmissing_lnpop(or);
        statepp(i,t)=nonmissing_state_fips(or);
         countypp(i,t)=nonmissing_countyreal(or);
        t=t+1;
    else  % new county
        i=i+1; t=1;
         lnemp(i,t)= nonmissing_lnemp_rest_both(or);
        lnemTOT(i,t)= nonmissing_lnemp_TOT(or);
        lnmw(i,t)= nonmissing_lnMW(or);
        lnPop(i,t)= nonmissing_lnpop(or);
        statepp(i,t)=nonmissing_state_fips(or);
         countypp(i,t)=nonmissing_countyreal(or);
        t=t+1;
        end
    end

end
N=1378; T= 66;
state=statepp(:,1); county=countypp(:,1);


%% create state dummy

 
stateindex(1)=state(1);
j=2;
for i=2:N
    if state(i)~= state(i-1)
        stateindex(j)=state(i);
        j=j+1;
    end
end
for j=1:length(stateindex)
    statedummy(:,j)=(state==stateindex(j)); % each column is one state dummy
end

  %%
clear lnemp_rest_both lnemp_TOT lnMW lnpop;
clear nonmissing_lnemp_rest_both nonmissing_lnemp_TOT nonmissing_lnMW nonmissing_lnpop;

Y=  lnemp; 
X(:,:,1)= lnmw;
X(:,:,2)=  lnPop;
X(:,:,3)= lnemTOT;  % not used before

 

%% create state level variables
 
d=3 ;

 % state 1378 by 1
 % stateindex 51 by 1

for j=1: length(stateindex)
  
    k=1;
    stateX(j,:,k)=log(mean(exp(X(state==stateindex(j),:,k)),1)); % state  lnmw
 % emp
    stateY(j,:)=log(sum(exp(Y(state==stateindex(j),:)),1));
       for  k=2:d
            stateX(j,:,k)=log(sum(exp(X(state==stateindex(j),:,k)),1));  
            % k=2  state lnPop
             % k=3 % state  lnemTOT
       end
  
           
    
 
end





clear X Y N
X= stateX; Y= stateY; N= length(stateindex);

 
% group

 
[a,b]= sort(nanmean(X(:,:,1),2), 'descend');
highMW =  b(1:round(N/3));
medianMW =  b(round(N/3)+1:round(N*2/3));
lowMW =  b(round(N*2/3)+1:end);
group(:,1)=highMW;
group(:,2)=medianMW;
group(:,3)=lowMW;

 
   

%% tunings

stdu=0.02;  
 

tuning=zeros(2,d);
 for or=1:100
   for r=1:d
    tuningb1(r,or)= norm(X(:,indexT(1:T/2),r).*randn(N,T/2)*stdu,2)*1.1  ;
    tuningb2(r,or)= norm(X(:,indexT(T/2+1:T),r).*randn(N,T/2)*stdu,2)*1.1  ;
   end
   tuning0b(or)=norm(randn(N,T/2)*stdu,2)*1.1 ; 
 end
tuning0= quantile(tuning0b,0.975);   %  14.3813
for r=1:d
tuning(1,r)= quantile(tuningb1(r,:),0.975);   
tuning(2,r)= quantile(tuningb2(r,:),0.975);   
% tuning1= 23.4079;  tuning(2)= 164.7912; tuning(3)= 147.980; 
end


  


    %% Estimate the structures in each X,  
  
 
 
   clear xx x yy y coeff Z  E   newX newXX
   
   

  
for r=1:d
    
    if r==1
        newXX=[ X(highMW,:,r); X(medianMW(1:7),:,r) ]; % all the others are the same, so ignored in PCA step
    else % r=2 or 3
        newXX= X(:,:,r);
    end
         
        newN=length(newXX(:,1));
    
       Z=newXX  -ones(newN,1)*mean(newXX,1)  ...
                    - mean(newXX,2)*ones(1,T)  + mean(mean(newXX,2))*ones(newN,T); 
         
  
      Sam_cov= Z*Z'/T; 
       [tempV,tempD]         =      eig(Sam_cov/newN);   
       [tempeig,tempidx]     =      sort(real(diag(tempD)),'descend');
       eigvec                =      tempV(:,tempidx); 
       u1                    =      eigvec(:,1:Kx(r));
       l = u1*sqrt(newN);  % newN by Kx(r)
       w =   Z'*l/newN; % T by Kx(r)
       factorstructure= l*w';
      
  
     newE =  Z- factorstructure ;
     newCommon = newXX -newE ;
    

       
     
 if r==1
        E(:,:,r)=zeros(N,T);
   E(highMW,:,r)= newE(1:17,:);
   E(medianMW(1:7),:,r)= newE(18:24,:);
   E(medianMW(8:17),:,r)= ones(10,1)*newE(24,:);  
   E(lowMW,:,r)= ones(17,1)*newE(24,:);  
   
    Common(:,:,r)=zeros(N,T);
   Common(highMW,:,r)= newCommon(1:17,:);
   Common(medianMW(1:7),:,r)= newCommon(18:24,:);
   Common(medianMW(8:17),:,r)= ones(10,1)*newCommon(24,:); 
   Common(lowMW,:,r)= ones(17,1)*newCommon(24,:);  
    else % r=2 or 3
        E(:,:,r)= newE ;
        Common(:,:,r)=newCommon ;
     end  %  if r==1

  clear xx x yy y coeff Z   newX   newN diff coeffold  Sam_cov tempV tempD
  clear tempeig tempidx eigvec  u1 l w factorstructure reshfactors 
  clear newE newCommon
     
end % r=1:d

   
    


clear a  b 



%indexT=randperm(T);
for r=1:d
X(:,:,r)=X(:,indexT,r);
E(:,:,r)=E(:,indexT,r);
Common(:,:,r)=Common(:,indexT,r);
end
Y=Y(:,indexT);
[a,rearrange]=sort(indexT, 'ascend');
clear a
   

 clear a b  high low group 
 
[a,b]= sort(nanmean( stateX(:,:,1),2), 'descend');
high =  b(1:round(N/2));
low  =  b(round(N/2):end);
 group(:,1)=high;
 group(:,2)=low;
 
 
 se= nan(N,3,T); 
 randtheta=nan(N,3,T); 
 stergroup= nan(2,3); 
 fixeffect= nan(N,T) ;
  convergence= nan(T,1);

  beta = nan(N,K(1),T) ;  % for testing within group homo
  var_beta= nan(N,K(1),T) ;   % for testing within group homo
 Corrmatrix= nan(K(1),K(1),T) ; % for testing within group homo



%% analysis

 
 
  parfor time = 1:T

    [randtheta(:,:,time),  se(:,:,time), stergroup(:,:,time), fixeffect(:,time), beta(:,:,time),   var_beta(:,:,time),   Corrmatrix(:,:,time), convergence(time)] = iterative_mw_laggedX_sub(Y,X, Common, E, time,  K, tuning,  tuning0, K0,group);
    
    % iterative_mw function itself is already time-randomly-arranged, but
    % does not split the sample or rearrange it. 
    % Need to   rearrange back after
    time
  
end % time 


 
%  individual se
 hatthetase=se(:,:,rearrange); % re-arranged, as the same time as the original time
Thetase=permute(hatthetase, [1,3,2]);  % Theta(N,T,d)
 result_se  = Thetase(:,:,1)  ;  % Nx T, 



hattheta=randtheta(:,:,rearrange); % re-arranged, as the same time as the original time, % hattheta(N,d,T)
Theta=permute(hattheta, [1,3,2]);  % Theta(N,T,d)
FixedEffect= fixeffect(:,rearrange); % N by T
 result_mw =Theta(:,:,1);  % Nx T, 

 
 
 % group se
 hatgroupse=stergroup(:,:,rearrange); % re-arranged, as the same time as the original time, %  
Thetasegroup=permute( hatgroupse, [1,3,2]);  % Theta(M,T,d)
 result_segroup =Thetasegroup(:,:,1);  % M x T, 

 
 
 crossmean_high_MW=nanmean(result_mw(high,:), 1);
 % crossmean_median_MW=nanmean(result_mw (medianMW,:), 1);
crossmean_low_MW=nanmean(result_mw(low,:), 1);

 
   tt=[1:T];
 tt = datetime(1990,01,01):calmonths(3):datetime(2006,06,28);
 

  
 subplot(1,2,1)
pp=plot(tt, crossmean_high_MW,'k',    tt,crossmean_low_MW,'b',...
    tt, crossmean_low_MW-1.96*result_segroup(2,:),':b' ,...
    tt,crossmean_low_MW+1.96*result_segroup(2,:),':b',...
    tt, crossmean_high_MW-1.96*result_segroup(1,:),':k' ,...
    tt,crossmean_high_MW+1.96*result_segroup(1,:),':k',...
    tt, zeros(1,length(tt)),'r',   'LineWidth', 3  );
 h_le= legend('high minimum wage states', 'low minimum wage states','location', 'best');
  title('Cross-Sectional Mean of Minimum Wage Effects' ,   'FontSize',18);
  set(h_le,'FontSize',16);
xlabel('year','FontSize',16) 
set(gca, 'FontSize', 20);   
 % xlimits: from   726830 to 732780
   

 subplot(1,2,2)
% largest: X(38,:,1), stateindex(38)=41, 41041 Oregon, the highest
% smallest: X(34,:,1), stateindex(34)=37, 37055 North Carolina, one of the smallest 
plot(tt, Theta(38,:,1),'k',   tt,Theta(34,:,1),'b',...
    tt, Theta(38,:,1)-1.96*result_se(38,:,1),':k',...
    tt, Theta(38,:,1)+1.96*result_se(38,:,1),':k',...
    tt,Theta(34,:,1)-1.96*result_se(34,:,1),':b',...
    tt,Theta(34,:,1)+1.96*result_se(34,:,1),':b',...
      tt, zeros(1,length(tt)),'r',   'LineWidth', 3  );
% ylim([-4 4])
 h_le= legend('Oregon:high Minimum Wage','North Carolina:low Minimum Wage','location', 'best');
  title('Two States Minimum Wage effects on employment' ,   'FontSize',18);
  set(h_le,'FontSize',16);
xlabel('year','FontSize',16) 
set(gca, 'FontSize', 20);   
 

%% within group homo test 

loading =  mean(beta,3) ; % N by 2
var_loading =  mean( var_beta,3) ; % N by 2
load_high = loading(high,:);
var_high = var_loading(high,:);
load_low = loading(low,:);
var_low = var_loading(low,:);

t_high = (load_high  - mean(load_high ,1)) ./sqrt(var_high) *sqrt(T) ;
t_low = (load_low   - mean(load_low  ,1)) ./sqrt(var_low ) *sqrt(T) ;

 Corrmatrix_final = mean(Corrmatrix,3)  ; % 2 by 2 
  sqcov=  Corrmatrix_final^(1/2) ;
  maxZ = nan(1000,1) ;
  for l = 1:length(maxZ) 
    Z= randn(size(t_low,1),size( sqcov,1))* sqcov ;
     maxZ(l)=  max(max( abs( Z )));
  end
phigh= mean( maxZ > max(max( abs(t_high )))) 
plow = mean( maxZ > max(max( abs(t_low )))) 
      %% P

for t=1:T
   
     crossmean_high_MW(t) ;
        crossmean_low_MW(t);
        
  
     
  
   sehigh(t)= result_segroup(1,t) ;
     selow(t)= result_segroup(2,t) ;
     
     pos_high(t)=crossmean_high_MW(t)-1.96*sehigh(t)>0;
     pos_low(t)=crossmean_low_MW(t)-1.96*selow(t)>0;
     
     neg_high(t)= crossmean_high_MW(t) +1.96*sehigh(t)<0;
     neg_low(t)= crossmean_low_MW(t)+1.96*selow(t)<0;
     
  
     
     
end


Tstar= 16;

% before 1994
mean( pos_high(1:Tstar))
mean( pos_low(1:Tstar))
mean( neg_high(1:Tstar))
mean( neg_low(1:Tstar))

mean(crossmean_high_MW(1:Tstar))
mean(crossmean_low_MW(1:Tstar))


% after 1994 thru last quarter of 1999

Tstar2=40;

mean( pos_high(Tstar+1:Tstar2))
mean( pos_low(Tstar+1:Tstar2))
mean( neg_high(Tstar+1:Tstar2))
mean( neg_low(Tstar+1:Tstar2))

mean(crossmean_high_MW(Tstar+1:Tstar2))
mean(crossmean_low_MW(Tstar+1:Tstar2))


% after 2000
mean( pos_high(Tstar2+1:end))
mean( pos_low(Tstar2+1:end))
mean( neg_high(Tstar2+1:end))
mean( neg_low(Tstar2+1:end))

mean(crossmean_high_MW(Tstar2+1:end))
mean(crossmean_low_MW(Tstar2+1:end))

   %% Q
   
      pos_ind=result_mw>1.96*result_se;
     neg_ind=result_mw<-1.96*result_se;
     
     
     % before 1996
     
     
      mean(mean(pos_ind(high,1:Tstar),1))  % 1 by T
     mean(mean(pos_ind(low,1:Tstar),1)) % 1 by T
     mean(mean(neg_ind(high,1:Tstar),1)) % 1 by T
     mean(mean(neg_ind(low,1:Tstar),1)) % 1 by T
  
     
     % 1996-1999
     
      mean(mean(pos_ind(high,Tstar+1:Tstar2),1))  % 1 by T
     mean(mean(pos_ind(low,Tstar+1:Tstar2),1)) % 1 by T
     mean(mean(neg_ind(high,Tstar+1:Tstar2),1)) % 1 by T
     mean(mean(neg_ind(low,Tstar+1:Tstar2),1)) % 1 by T
     
% after 1999

     mean(mean(pos_ind(high,Tstar2+1:end),1))  % 1 by T
     mean(mean(pos_ind(low,Tstar2+1:end),1)) % 1 by T
     mean(mean(neg_ind(high,Tstar2+1:end),1)) % 1 by T
     mean(mean(neg_ind(low,Tstar2+1:end),1)) % 1 by T
     

     %% compare with homo models: 
      % use downloaded "panel" package  " A Panel Data Toolbox for MATLAB"
% by Inmaculada C. Álvarez, Javier Barbero and José L. Zofío.

     % y_it = X_it * beta + two way fixed effect 



  group = 1 ; % 1= all, 2= high,   3= low
   switch group
       case 1
            G = [1:N]';
       case 2
           G= high;
       case 3
           G =low;
   end 

     Yg = Y(G,:) ;
     Xg= X(G,:,:);
 dYg =  Yg - mean(Yg,1) - mean(Yg,2) + mean(mean(Yg)) ;
 dXg =  Xg ; 
for i =1:3
    x = Xg(:,:,i) ;
    if  group  == 3 % low group 
          dXg(:,:,i) = x - mean(x,2)  ;
    else
       dXg(:,:,i) = x - mean(x,1) - mean(x,2) + mean(mean(x)) ;
    end
end
 dXstack = reshape(dXg, [], 3);
 dYstack = reshape(dYg, [], 1);
coef=  inv( dXstack'* dXstack)* dXstack'*dYstack ; 

res = dYstack - dXstack * coef ;
B = dXstack'*    dXstack ;
A= dXstack'* diag(res.^2) *dXstack ;
 

varia= inv(B)*A*inv(B);
se= sqrt(diag(varia));
eff = coef(1) 
se(1)
t= eff/se(1)
 
  