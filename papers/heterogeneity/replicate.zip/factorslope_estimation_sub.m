% The model
% Y_it = X1_it * Theta_1_ it +.... + Xd_it * Theta_d_it +   alpha_i*g_t+ u_it
% Theta_r_it = lambda_r_i* f_r_t 
% Xr_it = l_r_i * w_r_t + e_r_it,  r= 1...d
% Assume e_r_it 's are independent across r and t. 

%tu
%
% Inputs:
%         Y: N by T
%         X: N by T by d
%         time: the time "t" at which we make inference about Theta_d_it
%         tuning:  d by 1 vector of tunings for Theta1....Thetad 
%         tuning0:  1 by 1  tuning for the intercept fixed effect alpha*g
%         Kx: d by 1, num factors in each X, can be zero 
%         K: d by 1, num factors in each Theta , input K=0 if want to
%         estimate K
%         K0: 1 by 1, num factors in intercept, input K0=0 if want to
%         estimate K


% Outputs:
%        theta: N by d, the estimated theta at t=time, for all X
%        theta_nopar: N by d estimator without partial out
%         theta_nuclear: N by d nuclear norm penal only estimator 
%         ster: N by d ,     standard error
%          hatK: estimated ranks for theta 
 
%  

function [theta,  theta_nopar, theta_nuclear, ster,  hatK ] = factorslope_estimation_sub(Y,X, E,time, Kx, K, K0, tuning,  tuning0)


[N,T,d]=size(X);
     maxiter =   4000    ; % 2000 max iter in while for nuclear 
    % tau=  0.9*1/max(max(max(X.^2))); % step size
     toler= 1e-4 ;
     tau=nan(d,1) ;
        for r=1:d
        tau(r)= 0.9/max(max(X(:,:,r).^2)); % step size;
        end
    
   %% Estimate the factor structures in each X
   
  if E ==0 % if input E= 0, then we need PCA to estimate E , 
       %   if input E already , nonzero, then we do not need this part 
   E= nan(N,T,d);
    Common= nan(N,T,d);
   for r=1: d
       x=X(:,:,r);
        demeanX=  x -mean(x,2)*ones(1,T);  % N by T should always use this,
     %  demeanX=  x ;  % N by T in case, use this for a experiment to see  how bad it is
       if Kx(r)>0
       Sam_cov= demeanX*demeanX'/T;
       [tempV,tempD]         =      eig(Sam_cov/N);   
       [tempeig,tempidx]     =      sort(real(diag(tempD)),'descend');
       eigvec                =      tempV(:,tempidx); 
       u1                    =      eigvec(:,1:Kx(r));
       l = u1*sqrt(N);  % N by Kx(r)
       w =   demeanX'*l/N; % T by Kx(r)
       E(:,:,r)  =  demeanX -  l* w';
       Common(:,:,r) = l* w' + mean(x,2)*ones(1,T); %  should always use this,
      % Common(:,:,r) = l* w' ;  % use this for a experiment to see  how bad it is
       else % Kx(r)==0
           E(:,:,r)  =  demeanX ;
       Common(:,:,r) = mean(x,2)*ones(1,T);
       end
       % So the structure is  x = mean(x,2)*ones(1,T) +  l(:,:,r)* w(:,:,r)' +  E(:,:,r)  
       
   end  % for r 
     clear hB hB0     hB0old   hBold  x Z A U2 S2 V2 S2new s2 U1 S1 V1 S1new
     clear Delta12 Delta13 diff demeanX Sam_cov  tempV  tempD tempeig  tempidx
     clear eigvec  u1 
   end % if E ==0

   Common = X- E; 
   
     %% estimate residuals :
     % for one option of se 
     %  for estimating rank
     % for compare with nuclear norm penalization only estimator
      
   hB= zeros(N,T,d);
   hB0=  Y;
   diff=1;
   k=1;  


   while diff>toler && k<maxiter
    hB0old=hB0;
    hBold=hB; % intercept
    % hB
    
     % hB
    for r=1:d
         
        Z=Y-(hB0+ sum(X.*hB,3)-X(:,:,r).*hB(:,:,r));
        A=hB(:,:,r)-tau(r)*X(:,:,r).*(X(:,:,r).*hB(:,:,r)-Z);
        [U2,S2,V2]=svd(A);
        S2new=(S2-tau(r)*tuning(r)).*(S2>tau(r)*tuning(r));
        hB(:,:,r)=U2*S2new*V2';
  
    end
    % hB0
     Z=Y-sum(X.*hB,3);
    [U1,S1,V1]=svd(Z);
    S1new=(S1-tuning0).*(S1>tuning0);
    hB0=U1*S1new*V1';
  
    
    Delta12=hB0-hB0old;
    Delta13=hB-hBold;
    diff= sqrt(norm(Delta12,'fro')^2/(N*T) + norm(reshape(Delta13, N,d*T),'fro')^2/(N*T*d)); 
    
    k=k+1;
   end % while
   
   residual3=Y-hB0-sum(hB.*X,3);

    theta_nuclear= nan(N,d);
    for r = 1:d
       theta_nuclear(:,r)= hB(:,time,r)  ;
    end
   
   
 %% estimate number of factors 
 if K==0  % estimate it 
     K=nan(d,1); 
      Cthresh= 0.1; 
      for r= 1:d
             [tempV,S1,V1]=svd(hB(:,:,r));
            [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
            thrs = sqrt(tuning(r)* max(tempeig)) ; 
            a=sum(tempeig> thrs* Cthresh) ;
            K(r)= min(max(a,1), round((T-1)/2)  ) ; 
      end % r 
      hatK= K; 
 else hatK=0;
 end % if K==0 

   %% initial estimates to get some options of se 
   % get eigenvectors
   

       for r=1:d
           [tempV,S1,V1]=svd(hB(:,:,r));
            [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
               eigvec                =      tempV(:,tempidx); 
                U1                    =     [ eigvec(:,1:K(r)), zeros(N, max(K)-K(r))];
           tLambda1(:,:,r)=U1*sqrt(N) ; % N by Kr  corres to X
       end % r 

       %% the interactive effect 

        [tempV,S1,V1]=svd(hB0);
        [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');

          if  K0==0
                 thrs = sqrt(tuning0* max(tempeig)) ; 
                a=sum(tempeig> thrs*  Cthresh) ;
               K0= min(max(a,1), round((T-1)/2)  ); 
          end  % K0
         eigvec                =      tempV(:,tempidx); 
         U0                    =        eigvec(:,1:K0) ;
         tLambda0=U0*sqrt(N) ; % N by K  corres to X
 
         %% initial iterate 
 
      
   for s=1:T
       dm=[];
       for r=1:d
           dm=[dm,(X(:,s,r)*ones(1,K(r))).* tLambda1(:,1:K(r),r)];
       end
        design= [tLambda0,dm];
        ols= inv(design'*design)*design'*Y(:,s);
        tcons_factor(:,s)= ols(1:K0); % correp constant  , Tcx 1
       tfactor1(:,s)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
     
    %   residual(:,s) = Y(:,s)- design*ols  ;   % N by T
   end
   
  
    
   for i=1:N
       dm=[];
       pp=0;
       for r=1:d
           dm=[dm,(X(i,:,r)'*ones(1,K(r))).* tfactor1(pp+1: pp+K(r)   ,:)']; % T by ...
            pp=pp+K(r);
       end
        design= [tcons_factor',dm];
        ols= inv(design'*design)*design'*Y(i,:)';
       % tcons_loading(:,i)= ols(1:K0); % correp constant  , 
       %tloading1(:,i)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
      
      
   end
     
   
     % bresidual =residual;
      % bresidual(:,time)=[];
 
        bresidual3 =residual3;
       bresidual3(:,time)=[];

 
       
      
     
   %% Sample splitting 
        
    by=Y;
    bx=X;
    be=E;
    bcommon=  Common;
    by(:,time)=[]; % remove the time  th observation
    bx(:,time,:)=[]; % remove the time  th observation
    be(:,time,:)=[]; % remove the time  th observation
    bcommon(:,time,:)=[]; % remove the time  th observation
    
    
   thetahat= nan(N,d,2) ;
    thetahat_nopartialout= nan(N,d,2) ;
    
 
      
 
        varf3=zeros(N,d,2);
       varl3=zeros(N,d,2);
       
     converg=zeros(2,1); % nuclear converges or not

       gh= round((T-1)/2);

  for par=1:2
     


          lengthtime=length(by(1,:)); 
   
         switch par
          case 1
              timeindex1=[1:gh];
               timeindex2=[gh+1:lengthtime];
          case 2 
              timeindex1=[gh+1: lengthtime ];
              timeindex2=[1:gh]; 
      end % switch
      
        
      x=bx(:,timeindex1,:);
      y=by(:,timeindex1); 
      xc=[X(:,time,:), bx(:,timeindex2,:)];
      ec=[E(:,time,:), be(:,timeindex2,:)];
      yc=[Y(:,time),by(:,timeindex2)]; % N by Tc
      commonC=[Common(:,time,:), bcommon(:,timeindex2,:)];
       T1= length(y(1,:));
      Ic= length(yc(1,:)); 

        % u= [residual(:,time),bresidual(:, timeindex2) ];
  
       uuu= [residual3(:,time),bresidual3(:, timeindex2) ];
       
       

          %% low rank estimation
    
   hB= zeros(N,T1,d);
   hB0=  y;
   diff=1;
   k=1;  


   while diff>toler && k<maxiter
    hB0old=hB0;
    hBold=hB; % intercept
    % hB
    
     % hB
    for r=1:d
         
        Z=y-(hB0+ sum(x.*hB,3)-x(:,:,r).*hB(:,:,r));
        A=hB(:,:,r)-tau(r)*x(:,:,r).*(x(:,:,r).*hB(:,:,r)-Z);
        [U2,S2,V2]=svd(A);
        S2new=(S2-tau(r)*tuning(r)).*(S2>tau(r)*tuning(r));
        hB(:,:,r)=U2*S2new*V2';
  
    end
    % hB0
     Z=y-sum(x.*hB,3);
    [U1,S1,V1]=svd(Z);
    S1new=(S1-tuning0).*(S1>tuning0);
    hB0=U1*S1new*V1';
   
 
    
    Delta12=hB0-hB0old;
    Delta13=hB-hBold;
    diff= sqrt(norm(Delta12,'fro')^2/(N*T1) + norm(reshape(Delta13, N,d*T1),'fro')^2/(N*T1*d)); 
    
    k=k+1;
   end % while
   %% get eigenvectors
   
    if k +2  < maxiter
        converg(par)=1;
    else converg(par)=0;
    end
   % disp(k);
   
   
       for r=1:d
           [tempV,S1,V1]=svd(hB(:,:,r));
            [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
               eigvec                =      tempV(:,tempidx); 
                U1                    =     [ eigvec(:,1:K(r)), zeros(N, max(K)-K(r))];
           tLambda1(:,:,r)=U1*sqrt(N) ; % N by Kr  corres to X
       end
        [tempV,S1,V1]=svd(hB0);
        [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
         eigvec                =      tempV(:,tempidx); 
         U0                    =        eigvec(:,1:K0) ;
         tLambda0=U0*sqrt(N) ; % N by K0  corres to X
 
           
    clear hB hB0  hBold    hB0old  Z A U2 S2 V2 S2new    U1 S1 V1 S1new Delta12 Delta13 
    clear tempV S1 V1 tempeig tempidx   eigvec U1 U0 
    clear newyc newxc  
    
    
  
 
    
    
    %%    estimate partial out  
     

    % mineig_check(par)=0;  % check if ill conditioned design
    % eig_threshold = 1e-7;
    Ic= length(yc(1,:)); 
      
      tcons_factor= nan(K0,Ic); 
      tfactor1 = nan(sum(K),Ic);  %   dim(design) = K0+ sum(K)
      % dim(dm) = sum(K)
   for s=1:Ic
       dm=[];
       for r=1:d
           dm=[dm,(xc(:,s,r)*ones(1,K(r))).* tLambda1(:,1:K(r),r)];
       end
        design= [tLambda0,dm];
        ols= inv(design'*design)*design'*yc(:,s);
        tcons_factor(:,s)= ols(1:K0); % correp constant  , Tcx 1
       tfactor1(:,s)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
       %  if min(eig(design'*design))<eig_threshold
        %     mineig_check(par)=1;  % then ill posed
      %  end

    
       clear dm design ols  
   end
 
       
    % loadings
    
     tcons_loading= nan(K0,N); 
         tloading1 = nan(sum(K),N); 
    
   for i=1:N
       dm=[];
       pp=0;
       for r=1:d
           dm=[dm,(xc(i,:,r)'*ones(1,K(r))).* tfactor1(pp+1: pp+K(r)   ,:)']; % T by ...
            pp=pp+K(r);
       end
        design= [tcons_factor',dm];
        ols= inv(design'*design)*design'*yc(i,:)';
        tcons_loading(:,i)= ols(1:K0); % correp constant  , 
       tloading1(:,i)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
      
        clear dm design ols  
   end
     

   
    %% partial our estimator's inference
      pp=0;
        thetainitial= nan(N,length(yc(1,:)),d) ; 
    for r=1:d
      thetainitial(:,:,r)=tloading1(pp+1: pp+K(r) ,:)'*tfactor1(pp+1: pp+K(r),:) ; % N by Tc
      pp=pp+K(r);
    end
    newyc=yc-sum( commonC.*thetainitial, 3); 
    newxc=ec;
  
 
   
   % factors
       

    cons_factor=  nan(K0,Ic); 
     factor2= nan(sum(K),Ic);

   for s=1:Ic
       dm=[];
       for r=1:d
           dm=[dm,(newxc(:,s,r)*ones(1,K(r))).* tLambda1(:,1:K(r),r)];
       end
        design= [tLambda0,dm];
        ols= (design'*design)\design'*newyc(:,s);
        cons_factor(:,s)= ols(1:K0); % correp constant  , Tcx 1
       factor2(:,s)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
        
       clear dm design ols  
   end
  % loadings

    cons_loading=  nan(K0,N); 
       loading2= nan(sum(K),N); 
 
 

   for i=1:N
       dm=[];
       pp=0;
       for r=1:d
           dm=[dm,(newxc(i,:,r)'*ones(1,K(r))).* factor2(pp+1: pp+K(r)   ,:)']; % T by ...
            pp=pp+K(r);
       end
        design= [cons_factor',dm];
        ols= (design'*design)\design'*newyc(i,:)'; % ... by 1
        cons_loading(:,i)= ols(1:K0); % correp constant  , 
       loading2(:,i)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
       
   
      
             
        
       clear dm design ols  
   end % i 
    
     %% estimate theta
    pp=0;
     
    %  thetahat has been defined earlier 
   for r=1:d
      thetahat(:,r, par)=loading2(pp+1: pp+K(r) ,:)'*factor2(pp+1: pp+K(r),1) ; % N by 1 of estimated theta at t =time
        thetahat_nopartialout(:,r, par)= thetainitial(:,1,r) ;
      pp=pp+K(r);
   end % d
 
 
  
 
 
   %% standard error   

    
    pp=0;
    for r=1:d
  
      
   Vlambda1  =  loading2(pp+1: pp+K(r) ,:)* diag(ec(:,1,r).^2)* loading2(pp+1: pp+K(r) ,:)'/N;
      Se= diag( ec(:,:,r)*ec(:,:,r)'/Ic); % N by 1
       Sf= factor2(pp+1: pp+K(r),:)*factor2(pp+1: pp+K(r),:)'/Ic;
        
       % full sample
      
       w= ec(:,:,r).* uuu; 
       
       Sw= diag( w*w'/Ic);  % N by 1
       Vlambda2  =  loading2(pp+1: pp+K(r) ,:)*  diag(w(:,1).^2)* loading2(pp+1: pp+K(r) ,:)'/N;
       Vlambda = inv( Vlambda1)*  Vlambda2 * inv( Vlambda1);
       varl3(:, r, par) =diag(loading2(pp+1: pp+K(r) ,:)'* Vlambda *  loading2(pp+1: pp+K(r) ,:) )   ;  % N by 1 % lambda_i'*V_lambda* lambda_i 
      varf3(:, r, par) = factor2(pp+1: pp+K(r),1)'  *inv(Sf) * factor2(pp+1: pp+K(r),1)*   (   Sw./(Se.^2)  ) ;% N by 1,  f_t'V_f f_t 
      
   
      
      pp=pp+K(r);
      
      
      
      
  end % d
 

   %% 
   
    
   
   clear u w; 
  
  
   clear tcons_factor tfactor1   tloading1  tcons_loading tLambda1 tLambda0 
   clear newyc newxc yc xc Ic  loading2  factor2  thetainitial
   clear  cons_factor    cons_loading  
   clear   x y   ec   commonC T1 w u       
   
 end % par    


 theta= (thetahat(:,:, 1) +thetahat(:,:, 2))/2; % N by d
 theta_nopar = (thetahat_nopartialout(:,:, 1) +thetahat_nopartialout(:,:, 2))/2;

  
  
     %% standard error summary 

    Ic = round((T-1)/2)+1 ; 
     
   
         % full sample method 4
    
        
      fullvar_est=  varl3(:,:,1)/N + varf3(:,:,1) /Ic+varl3(:,:,2)/N + varf3(:,:,2) /Ic...
              +  varl3(:,:,1)/N+ varl3(:,:,2)/N; % N by d
         ster=  1/2* sqrt(fullvar_est) ;    % N by d , standard error
     
     

          