
 function    [theta_ind , theta_time,  theta_hom]= fixe_effct_alternative(Y,X, K0, time, individual)
% alternative "interactive effect estimators", not low-rank approach 
%      Y: N by T
%      X: N by T by d
%      K0: num factors in interactive fixed effect 
%    time: which time we are interested in 
%   individual : which individual 
% 
 
% theta_ind: i -hetero
% theta_time: t-hetero
% theta_homo: all homo
 

[N,T,dimX ] = size(X) ; 
K=K0; % rank of interactive fixed effect

%% individual hetero 
Ynew= Y; 
theta =zeros(dimX,N);
diff =10; 
k=0; 


while diff>1e-7 & k<200 
    thetaold = theta; 
    E= nan(N,T); 
    for i=1:N
        Xi = nan(T,dimX); 
        for r= 1:dimX 
          Xi(:,r) = X(i,:,r)';
        end
        theta(:,i)= (Xi'*Xi) \ Xi'*Ynew(i,:)';
        E(i,:)= Y(i,:) -    theta(:,i)'* Xi';
    end 
    S= E'*E; % T by T
    [s,v] = eigs(S,K); 
    F= s*sqrt(T); 
    L= E*F/T; 
    Ynew= Y- L * F' ; 
    diff = norm(theta -thetaold,'fro' )^2/(N*dimX) ; 
    k=k+1; 
end % while 
theta_ind =theta(1,individual); 

 
 %% time hetero 
Ynew= Y; 
theta =zeros(dimX,T);
diff =10; 
k=0; 


while diff>1e-7 & k<200 
     thetaold = theta; 
    E= nan(N,T); 
    for t = 1:T
         Xt = nan(N,dimX); 
         for r= 1:dimX 
          Xt(:,r) = X(:,t,r);
         end
         theta(:,t)= (Xt'*Xt) \ Xt'*Ynew(:,t);
         E(:,t)= Y(:,t) -    Xt*theta(:,t) ;
    end % t
      S= E'*E; % T by T
    [s,v] = eigs(S,K); 
    F= s*sqrt(T); 
    L= E*F/T; 
    Ynew= Y- L * F' ; 
    diff = norm(theta -thetaold,'fro' )^2/(N*dimX) ; 
    k=k+1; 
end % while 
theta_time =theta(1,time); 


 

%% homo 
Ynew= Y; 
theta =zeros(dimX,1);
diff =10; 
k=0; 

while diff>1e-7 & k<200 
    thetaold = theta; 
    E= nan(N,T);
     XNT =nan(N*T,dimX); 
    for r= 1:dimX 
        XNT(:,r)= reshape(X(:,:,r),N*T,1); 
    end % r 
    theta = ( XNT'* XNT) \  XNT'*reshape(Ynew,N*T,1) ;
     for t = 1:T
          Xt = nan(N,dimX); 
           for r= 1:dimX 
            Xt(:,r) = X(:,t,r);
           end
            E(:,t)= Y(:,t) -    Xt*theta  ;
     end % t 
      S= E'*E; % T by T
    [s,v] = eigs(S,K); 
    F= s*sqrt(T); 
    L= E*F/T; 
    Ynew= Y- L * F' ; 
    diff = norm(theta -thetaold,'fro' )^2/(N*dimX) ; 
    k=k+1; 

end % while 
theta_hom =theta(1); 

 
 