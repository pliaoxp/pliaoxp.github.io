%  X has lagged in its common components
%  X_it = a X_{i,t-1} + l_iw_t+ e_it, for all X
%  works with laggedX_mw.m

% The model
% Y_it = X1_it * Theta_1_ it +.... + Xd_it * Theta_d_it +   alpha_i*g_t+ u_it
% Theta_r_it = lambda_r_i* f_r_t 
% Xr_it = l_r_i * w_r_t + e_r_it,  r= 1...d
% Assume e_r_it 's are independent across r and t. 
% application min wage only
%
% Inputs:
%         Y: N by T
%         X: N by T by d
%      Common: N by T by d , common components in X
%         E: N by T by d, residual componentS in X, should be serially
%         independent
%         time: the time "t" at which we make inference about Theta_d_it
%         tuning:  2 by d vector of tunings for Theta1....Thetad ; first
%         row is for the first half splitting sample; the second row is for
%         the second half splitting sample
%         tuning0:  1 by 1  tuning for the intercept fixed effect alpha*g
%         K: d by 1, num factors in each Theta 
%         K0: 1 by 1, num factors in intercept
%         group: GG by M:  GG is the number of individuals in each group, M
%         is the number of groups we want to estimate. 
                 %  each column is indices of the cross sections for each group. If the group size is
          %         not the same, GG is the max group size, and all other
          %         groups put zeros
          % for instance, we want to estimate two groups: Group 1: individuals {1,3};
          % and group 2: individuals {2,5,6}. Then group= [  1,2;3,5;0,6  ]
          % and GG=3
          % set group =0 if not estimate any group


% Outputs:
%        theta: N by d, the estimated theta at t=time, for all X
%         ster: N by d, standard error
%  convergence: 1 if the nuclear minimization is convergent; 0 otherwise
%    stergroup:  M by d, group standard error, if group =0 then stergroup=0
%    fixeffect: N by 1, the estimated interactive fixed effect at time t.
%     Corrmatrix: used to do within-group homo test 
%  beta_final,   var_beta_final: estimated loading of coeff of first X, and  its variance

function [theta,   ster, stergroup,fixeffect, beta_final,   var_beta_final,    Corrmatrix, convergence ] = iterative_mw_laggedX_sub(Y,X,Common, E, time,  K, tuning,  tuning0, K0, group)
 
 
[GG, M]=size(group);
[N,T,d]=size(X);
     maxiter =   4000    ; % max iter in while for nuclear 
      whilethres= 1e-5; 
  
        beta = nan(N,K(1),2);  % loading of theta of the first X
     var_beta   = nan(N,K(1),2);  % variance of beta 
     for r=1:d
        tau(r)= 0.9/max(max(X(:,:,r).^2)); % step size;
     end
   
    % tau= 0.2180    0.0030    0.0034
     
          varl3 = nan(N,d,2);
        varf3 = nan(N,d,2);
      se = nan(N,d,2);
     varlgp =nan(M,d,2) ;
      varfgp=nan(M,d,2) ;

   %% estimate residuals for se 


   hB=  zeros(N,T,d);
   hB0=  Y;
   diff=1;
   k=1;  

   h= 3 ;  % for tuning 
 
 tuningOriginal  =[0.4742    4.3632    4.1600
    0.4681    4.3707    4.1430] *h;

 tuning=  tuningOriginal   ;
 tuning0 = 0.2933  *h  ;

   while diff> whilethres && k<maxiter
    hB0old=hB0;
    hBold=hB; % intercept
   
     % hB
    for r=1:d
         
        Z=Y-(hB0+ sum(X.*hB,3)-X(:,:,r).*hB(:,:,r));
        A=hB(:,:,r)-tau(r)*X(:,:,r).*(X(:,:,r).*hB(:,:,r)-Z);
        [U2,S2,V2]=svd(A);
        S2new=(S2-tau(r)*tuning(1,r)).*(S2>tau(r)*tuning(1,r));
        hB(:,:,r)=U2*S2new*V2';
  
    end
  
     % hB0
     Z=Y-sum(X.*hB,3);
    [U1,S1,V1]=svd(Z);
    S1new=(S1-tuning0).*(S1>tuning0);
    hB0=U1*S1new*V1';
    
    Delta12=hB0-hB0old;
    Delta13=hB-hBold;
    diff= sqrt(norm(Delta12,'fro')^2/(N*T) + norm(reshape(Delta13, N,d*T),'fro')^2/(N*T*d));
    
    k=k+1;
   end % while

   residual3=Y-hB0-sum(hB.*X,3);
    



       for r=1:d
           [tempV,S1,V1]=svd(hB(:,:,r));
            [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
               eigvec                =      tempV(:,tempidx); 
                U1                    =     [ eigvec(:,1:K(r)), zeros(N, max(K)-K(r))];
           tLambda1(:,:,r)=U1*sqrt(N) ; % N by Kr  corres to X
       end % r 

       %  the interactive effect 

        [tempV,S1,V1]=svd(hB0);
        [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');

          if  K0==0
                 thrs = sqrt(tuning0* max(tempeig)) ; 
                a=sum(tempeig> thrs*  Cthresh) ;
               K0= min(max(a,1), round((T-1)/2)  ); 
          end  % K0
         eigvec                =      tempV(:,tempidx); 
         U0                    =        eigvec(:,1:K0) ;
         tLambda0=U0*sqrt(N) ; % N by K  corres to X
 
         %  initial iterate 
 
      
   for s=1:T
       dm=[];
       for r=1:d
           dm=[dm,(X(:,s,r)*ones(1,K(r))).* tLambda1(:,1:K(r),r)];
       end
        design= [tLambda0,dm];
        ols= inv(design'*design)*design'*Y(:,s);
        tcons_factor(:,s)= ols(1:K0); % correp constant  , Tcx 1
       tfactor1(:,s)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
     
    %   residual(:,s) = Y(:,s)- design*ols  ;   % N by T
   end
   
  
    
   for i=1:N
       dm=[];
       pp=0;
       for r=1:d
           dm=[dm,(X(i,:,r)'*ones(1,K(r))).* tfactor1(pp+1: pp+K(r)   ,:)']; % T by ...
            pp=pp+K(r);
       end
        design= [tcons_factor',dm];
        ols= inv(design'*design)*design'*Y(i,:)';
    
      
   end
     
 
 
        bresidual3 =residual3;
       bresidual3(:,time)=[];

  
   clear tcons_factor tfactor1   tloading1  tcons_loading tLambda1 tLambda0 
   clear newyc newxc yc xc   loading2  factor2  thetainitial
   clear  cons_factor    cons_loading  
     


   %% Sample splitting 
        
    by=Y;
    bx=X;
    be=E;
    bcommon=  Common;
    by(:,time)=[]; % remove the time  th observation
    bx(:,time,:)=[]; % remove the time  th observation
    be(:,time,:)=[]; % remove the time  th observation
    bcommon(:,time,:)=[]; % remove the time  th observation
    
    
 
         lengthtime=length(bx(1,:,1)); 
       
     converg=zeros(2,1); % nuclear converges or not
  for par=1:2
     
      
    if par==1
        %e=be(:,1:round(T-2)/2,:);
        x=bx(:,1:round(T-2)/2,:);
        y=by(:,1:round(T-2)/2);
        %common=bcommon(:,1:round(T-2)/2,:);
        xc=[X(:,time,:), bx(:,round(T-2)/2+1:end,:)];
        ec=[E(:,time,:), be(:,round(T-2)/2+1:end,:)];
        yc=[Y(:,time),by(:,round(T-2)/2+1:end)]; % N by Tc
        commonC=[Common(:,time,:), bcommon(:,round(T-2)/2+1:end,:)];
         T1= length(y(1,:));
             timeindex2=[round(T-2)/2+1:   lengthtime];
    else % par==2
         x=bx(:,round(T-2)/2+1:end,:);
         %e=be(:,round(T-2)/2+1:end,:);
         y=by(:,round(T-2)/2+1:end);
         %common=bcommon(:,round(T-2)/2+1:end,:);
         xc=[X(:,time,:),bx(:,1:round(T-2)/2,:)];
         ec=[E(:,time,:),be(:,1:round(T-2)/2,:)];
         yc=[Y(:,time),by(:,1:round(T-2)/2)]; % N by Tc
         commonC=[Common(:,time,:),bcommon(:,1:round(T-2)/2,:)];
          T1= length(y(1,:));
              timeindex2=[1:round(T-2)/2];
    end
    
       uuu= [residual3(:,time),bresidual3(:, timeindex2) ];  % set h=3
       
       

          %% low rank estimation
    
   hB=  zeros(N,T1,d);
   hB0=  y;
   diff=1;
   k=1;  

 
 tuningOriginal  =[0.4742    4.3632    4.1600
    0.4681    4.3707    4.1430];

 tuning=  tuningOriginal  /8;
 tuning0 = 0.2933 /5  ;

   while diff> whilethres && k<maxiter
    hB0old=hB0;
    hBold=hB; % intercept
   
     % hB
    for r=1:d
         
        Z=y-(hB0+ sum(x.*hB,3)-x(:,:,r).*hB(:,:,r));
        A=hB(:,:,r)-tau(r)*x(:,:,r).*(x(:,:,r).*hB(:,:,r)-Z);
        [U2,S2,V2]=svd(A);
        S2new=(S2-tau(r)*tuning(par,r)).*(S2>tau(r)*tuning(par,r));
        hB(:,:,r)=U2*S2new*V2';
  
    end
  
     % hB0
     Z=y-sum(x.*hB,3);
    [U1,S1,V1]=svd(Z);
    S1new=(S1-tuning0).*(S1>tuning0);
    hB0=U1*S1new*V1';
    
    Delta12=hB0-hB0old;
    Delta13=hB-hBold;
    diff= sqrt(norm(Delta12,'fro')^2/(N*T1) + norm(reshape(Delta13, N,d*T1),'fro')^2/(N*T1*d));
    
    k=k+1;
   end % while



    if k +2  < maxiter
        converg(par)=1;
    else converg(par)=0;
    end
   % disp(k);
   
   
       for r=1:d
           if norm(hB(:,:,r),'fro')/sqrt(N*T1)<1e-5 %  zero, no factors
          K(r)=0;
           end
       end
       if  norm(hB0,'fro')/sqrt(N*T1)<1e-5
           K0=0;
       end
   
       for r=1:d
           [tempV,S1,V1]=svd(hB(:,:,r));
            [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
               eigvec                =      tempV(:,tempidx); 
                U1                    =     [ eigvec(:,1:K(r)), zeros(N, max(K)-K(r))];
           tLambda1(:,:,r)=U1*sqrt(N) ; % N by Kr  corres to X
       end
       
        [tempV,S1,V1]=svd(hB0);
        [tempeig,tempidx]     =      sort(real(diag(S1)),'descend');
         eigvec                =      tempV(:,tempidx); 
         U0                    =        eigvec(:,1:K0) ;
         tLambda0=U0*sqrt(N) ; % N by K0
       
           
    clear hB hB0  hBold    hB0old  Z A U2 S2 V2 S2new    U1 S1 V1 S1new Delta12 Delta13 
    clear tempV S1 V1 tempeig tempidx   eigvec U1 U0 
    clear newyc newxc  
    
    
  
 
    
    
    %%    estimate partial out  
    
   
    Ic= length(yc(1,:)); 
      
   for s=1:Ic
       dm=[];
       for r=1:d
           dm=[dm,(xc(:,s,r)*ones(1,K(r))).* tLambda1(:,1:K(r),r)];
       end
       
           design= [tLambda0,dm];
            ols= inv(design'*design)*design'*yc(:,s);
           tcons_factor(:,s)= ols(1:K0); % correp constant  , Tcx 1
           tfactor1(:,s)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
        
       
       clear dm design ols  
   end
 
       
    % loadings
    
      
    
   for i=1:N
       dm=[];
       pp=0;
       for r=1:d
           dm=[dm,(xc(i,:,r)'*ones(1,K(r))).* tfactor1(pp+1: pp+K(r)   ,:)']; % T by ...
            pp=pp+K(r);
       end
        design= [tcons_factor',dm];
        ols= inv(design'*design)*design'*yc(i,:)';
        tcons_loading(:,i)= ols(1:K0); % correp constant  , 
       tloading1(:,i)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
      
        clear dm design ols  
   end
     
   
   
      pp=0;
    for r=1:d
        if K(r)>0
      thetainitial(:,:,r)=tloading1(pp+1: pp+K(r) ,:)'*tfactor1(pp+1: pp+K(r),:) ; % N by Ic
        else  thetainitial(:,:,r)=zeros(N, Ic); 
        end
         pp=pp+K(r);
    end
    newyc=yc-sum( commonC.*thetainitial, 3); 
    newxc=ec;
  
  %% inference
   
   % factors
      
   for s=1:Ic
       dm=[];
       for r=1:d
           dm=[dm,(newxc(:,s,r)*ones(1,K(r))).* tLambda1(:,1:K(r),r)];
       end
        design= [tLambda0,dm];
        ols= (design'*design)\design'*newyc(:,s);
        cons_factor(:,s)= ols(1:K0); % correp constant  , Tcx 1
       factor2(:,s)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
        
       clear dm design ols  
   end
  % loadings
     
   for i=1:N
       dm=[];
       pp=0;
       for r=1:d
           dm=[dm,(newxc(i,:,r)'*ones(1,K(r))).* factor2(pp+1: pp+K(r)   ,:)']; % T by ...
            pp=pp+K(r);
       end
        design= [cons_factor',dm];
        ols= (design'*design)\design'*newyc(i,:)'; % ... by 1
        cons_loading(:,i)= ols(1:K0); % correp constant  , 
       loading2(:,i)= ols(K0+1:end);  % corresp X   , arranged as r=1, r=2,... r=d
       
       % residual 
     %  u(i,:) = newyc(i,:) -     ols' * design' ;   % N by T
       
       clear dm design ols  
   end
   
   %% estimate theta for inference
    pp=0;
    
   
     
     
   for r=1:d
        if K(r)>0


      thetahat(:,r, par)=loading2(pp+1: pp+K(r) ,:)'*factor2(pp+1: pp+K(r),1) ; % N by 1 of estimated theta at t =time
      
     beta(:,:,par)= loading2(1: K(1) ,:)'; % N by K 
        
      %% individual  standard error

     
 
      w= ec(:,:,r).* uuu; 



     dSe= diag( ec(:,:,r)*ec(:,:,r)'/Ic); % N by 1
          dSw= diag( w*w'/Ic);  % N by 1
    Se= diag(dSe); % N by N
  Sf =  factor2(pp+1: pp+K(r),:)* factor2(pp+1: pp+K(r),:)'/ Ic;
    Vlambda1  =  loading2(pp+1: pp+K(r) ,:)* Se* loading2(pp+1: pp+K(r) ,:)'/N; % num factor by num factor
    homow=  dSw./(dSe.^2) ; % N by 1

 

   
       Sw= diag( dSw);  % N by N
       Vlambda2  =  loading2(pp+1: pp+K(r) ,:)* Sw* loading2(pp+1: pp+K(r) ,:)'/N;
       Vlambda = inv( Vlambda1)*  Vlambda2 * inv( Vlambda1); % num factor by num factor
       sel =diag(loading2(pp+1: pp+K(r) ,:)'* Vlambda *  loading2(pp+1: pp+K(r) ,:) ) /N   ;  % N by 1 % lambda_i'*V_lambda* lambda_i/N
       daf = factor2(pp+1: pp+K(r),1)'* inv(Sf) * factor2(pp+1: pp+K(r),1);  % 1 by 1
       sef =  daf*   homow /Ic; % N by 1,  f_t'V_f f_t/ T
       se(:, r, par)=sqrt(sel+sef); % N by 1, std error
    
 
       if r==1 % focus on the minimum wage effect 
             
           S1= inv( Sf ); 
           S2 = diag(S1);
           Corrmatrix =  diag(sqrt(1./S2))*S1* diag(sqrt(1./S2)) ; % used for within group homo test
         
        var_beta(:,:,par) =  homow *  diag(S1)'; % N by K % used for within group homo test
       end 

       %% group standard error
        
      if norm(group)>0 % want to estimate group 
      %    groupster:  M by d, group standard error
        [GG, M]=size(group);
         for g=1: M
             G= sum(group(:,g)>0) ; %   size of group g
             membership= group(1:G ,g);
             barlambda=mean(loading2(pp+1: pp+K(r) ,membership),2); % num factor by 1
 
            
             selgroup = barlambda'*Vlambda* barlambda/N; % scalar  old
            daf = factor2(pp+1: pp+K(r),1)'* inv(Sf) * factor2(pp+1: pp+K(r),1);  % 1 by 1 % old 
             sefgroup=daf* mean(  homow(membership) ) /(Ic*G); % scalar  old
          segroup(g,r ,par)= selgroup+sefgroup ; % new  old
            

           clear membership barlambda G
         end % g
      
      end % group
      
        else  thetahat(:,r, par)=zeros(N, 1);  %  K(r)==0
        
            varl3(:, r, par) =zeros(N, 1); 
            varf3(:, r, par) =zeros(N, 1); 
             varfgp(:, r, par)=zeros(M,1);
             varlgp(:, r, par)=zeros(M,1);
        end % if K(r)>0
        
   

       pp=pp+K(r);
      
      clear   Vlambda1 Vlambda2 w   Vlambda Sf Se Sw daf sef sel
   end % r=1:d
    
   
    %%   fix effect
      
      fixeffect= cons_loading'* cons_factor(:,1);  % N by 1
      
      
   
   clear u w; 
  
  
   clear tcons_factor tfactor1   tloading1  tcons_loading tLambda1 tLambda0 
   clear newyc newxc yc xc   loading2  factor2  thetainitial
   clear  cons_factor    cons_loading  
   clear   x y   ec   commonC T1 w u       
   
 end % par    
   


 theta= (thetahat(:,:, 1) +thetahat(:,:, 2))/2; % N by d
    beta_final = (beta(:,:,1) + beta(:,:,2))/2; % the loading of the coeff for first X. 
       var_beta_final =(var_beta(:,:,1)+ var_beta(:,:,2)  ) /2; % variance of beta_final


   if sum(converg)==2
       convergence =1;  % nuclear converges
   else convergence =0; % nuclear does not converge
   end

%%  se 
 if norm(group)>0

         stergroup =   sqrt((segroup(:,: ,1)+ segroup(:,: ,2))/2); %   old  M by d group standard error, M= num groups

    else stergroup=0;
 end  % if norm(group)>0

 ster = (se(:, :, 1)+ se(:, :, 2))/2; % N by d, standard error

 