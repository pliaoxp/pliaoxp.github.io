function  [cover_all, estK, zvalue_all,error_all ] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)   


% error_all = ours, no partialout, nuclear, i-hetero method, t-hetero method,homo
% error_all = etimator - truth
  

 K=   [2,2]; % rank in coefficients 

 time=1 ; 
individual =1 ; 
K0=1;   % rank in fixed  effect 
 Kx=   [2,1];   % rank in X 
dX= length(Kx); 


algo_convergence= nan(Rep,1); 
z= nan(Rep,1); 
coverage =  nan(Rep,1); 

delta_nopartial = nan(Rep,1);
delta_nuclear = nan(Rep,1);
 delta  = nan(Rep,1);

 delta_ind = nan(Rep,1);
delta_time = nan(Rep,1);
delta_hom = nan(Rep,1);
 

noise_ratioX = 0.4* ones(dX,1) ;

hatK = nan(dX,Rep);


parfor or=1:Rep
   
 
    
[Y,X,theta, interac_eff,sey] =   DGP_arti(N,T,K, K0, Kx, rho,homomodel , fixeffect,noise_ratioX) ;

 
tuning=zeros(2,1);
tuning(1)= norm(X(:,:,1).*randn(N,T)*sey,2)*1.1;
tuning(2)= norm(X(:,:,2).*randn(N,T)*sey,2)*1.1;
tuning0= norm(randn(N,T),2)*1.1;

E = 0;  % estimate E in the algorithm, do not need to input E 

Khat=  0;  % 0=estimate   %K; 
K0hat =  0;  % 0=estimate     %K0; 

[theta_est,   theta_nopar, theta_nuclear,  ster,  hatK(:,or)] =  factorslope_estimation_sub(Y,X, E,time, Kx, Khat, K0hat, tuning,  tuning0)  ;

  [theta_ind , theta_time,  theta_hom]= fixe_effct_alternative(Y,X, K0, time, individual) ; 
 

%% no need , produce the same as    factorslope_estimation(Y,.....ing,  tuning0)  ;

 
 
delta(or)= theta_est(individual,1)-theta(individual,time,1);  % 1= the first coefficienet theta1

    
    z(or)=delta(or) /ster(individual,1) ;  % 1= the first coefficienet theta1
    coverage(or)=abs(z(or))< norminv(0.975);
    


delta_nopartial(or)= theta_nopar(individual,1)-theta(individual,time,1);
delta_nuclear(or)= theta_nuclear(individual,1)-theta(individual,time,1);

% other methods 
delta_ind(or) = theta_ind - theta(individual,time,1); 
delta_time(or) =theta_time - theta(individual,time,1); 
delta_hom(or) =theta_hom - theta(individual,time,1); 
 
 
    if mod(or,500) == 0
        or
    end
 
end % or


coverage_ours= mean(coverage) ; % close to 95%
g= delta_nopartial;
 z_nopartial = g/std(g); 
cover_nopartialout= mean(abs( z_nopartial)< norminv(0.975)) ;


g= delta_nuclear;
z_nuclear=  g/std(g); 
cover_nuclear= mean(abs(z_nuclear)< norminv(0.975)) ;

estK = mean(hatK ,2)' ;  % truth = [2,2]

% other methods 

g=delta_ind;
cover_ind = mean(abs(g/std(g))< norminv(0.975)) ;

g=delta_time;
cover_time = mean(abs(g/std(g))< norminv(0.975)) ;

g=delta_hom;
cover_hom = mean(abs(g/std(g))< norminv(0.975)) ;

%% summary 

 % the first of each vector is our method.
 
cover_all=[coverage_ours, cover_nopartialout, cover_nuclear, cover_ind ,cover_time, cover_hom];
zvalue_all = [z,  z_nopartial, z_nuclear] ;
error_all  = [delta,  delta_nopartial, delta_nuclear,delta_ind,delta_time, delta_hom] ;

