c = parcluster('local');
c.NumWorkers = 32;
%saveProfile(c);


if isempty(gcp('nocreate'))
    parpool(c, 32);
end

rng(42, 'combRecursive'); % random seed 


% master simulation file for all cases 

Rep = 1000;  

N = 50; T= 50; 

 % error = ours, nopartialout, nuclear, ind ( i-hetero), time (t-hetero), homo 

%% case 1 

fixeffect= 'interactive' ;  %  'interactive' or 'twoway'
homomodel = 'hetero' ; % hetero ,  'indivihomo,   'timehomo', 'homo' 
rho=0; 



  % ours ,nopartial, nuclear
 [cover_hetero, estK_hetero, zvalue_hetero,error_hetero] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)  ; 

 bias_hetero = mean(error_hetero,1).^2  ; 
 var_hetero = var(error_hetero,0,1) ; 

rho=0.5 ; 
 [cover_depent, estK_depent, zvalue_depent,error_depent] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)  ; 
 bias_depent = mean(error_depent,1).^2  ; 
 var_depent = var(error_depent,0,1) ; 
 
%% case 2
   display('case 2  i hetero') 

fixeffect= 'interactive' ;  %  'interactive' or 'twoway'
homomodel = 'timehomo' ; % hetero ,  'indivihomo,   'timehomo', 'homo' 

  rho=0; 
 [cover_i, estK_i, zvalue_i,error_i] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)  ; 

rho=0.5 ; 
 [cover_i_depent, estK_i_depent, zvalue_i_depent,error_i_depent] = simulation_func(N,T,rho,fixeffect, homomodel,Rep) ;  


 bias_i = mean(error_i,1).^2  ; 
 var_i = var(error_i,0,1) ; 
  bias_i_depent = mean(error_i_depent,1).^2 ; 
 var_i_depent= var(error_i_depent,0,1) ;



 %% case 3
 display('case 3 t hetero')

fixeffect= 'interactive' ;  %  'interactive' or 'twoway'
homomodel = 'indivihomo' ; % hetero ,  'indivihomo,   'timehomo', 'homo' 

rho=0; 
 [cover_t, estK_t, zvalue_t,error_t] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)   ;

rho=0.5 ; 
 [cover_t_depent, estK_t_depent, zvalue_t_depent,error_t_depent] = simulation_func(N,T,rho,fixeffect, homomodel,Rep) ;  


  bias_t= mean(error_t,1).^2  ; 
 var_t = var(error_t,0,1) ; 
  bias_t_depent = mean(error_t_depent,1).^2 ; 
 var_t_depent = var(error_t_depent,0,1) ; 

  

   %% case 4 
 display('case 4, homo')
   
fixeffect= 'interactive' ;  %  'interactive' or 'twoway'
homomodel = 'homo' ; % hetero ,  'indivihomo,   'timehomo', 'homo' 

  rho=0; 
 [cover_hom, estK_hom, zvalue_hom,error_hom] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)   ;

rho=0.5 ; 
 [cover_hom_depent, estK_hom_depent, zvalue_hom_depent,error_hom_depent] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)   ;

   
 bias_hom = mean(error_hom,1).^2  ; 
 var_hom = var(error_hom,0,1) ; 
  bias_hom_depent = mean(error_hom_depent,1).^2 ; 
 var_hom_depent= var(error_hom_depent,0,1) ; 
 


 %% case 5 
 display('case 5, twoway')
 
fixeffect= 'twoway' ;  %  'interactive' or 'twoway'
homomodel = 'hetero' ; % hetero ,  'indivihomo,   'timehomo', 'homo' 

  rho=0; 
 [cover_2way, estK_2way, zvalue_2way,error_2way] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)   ;

rho=0.5 ; 
 [cover_2way_depent, estK_2way_depent, zvalue_2way_depent,error_2way_depent] = simulation_func(N,T,rho,fixeffect, homomodel,Rep)  ; 

 
 bias_2way = mean(error_2way,1).^2  ; 
 var_2way = var(error_2way,0,1) ; 
  bias_2way_depent= mean(error_2way_depent,1).^2  ; 
 var_2way_depent = var(error_2way_depent,0,1) ;

 


 

%% display outputs 





index = [1, 3:6];  

   hetero_iid= [ sqrt(bias_hetero(index)) *10;  bias_hetero(index)+var_hetero(index) ] 
hetero_depend= [  sqrt(bias_depent(index)) *10 ; bias_depent(index)+var_depent(index) ]  

i_iid= [  sqrt(bias_i(index))   *10;  bias_i(index)+var_i(index) ]  
i_depend= [   sqrt(bias_i_depent(index)) *10  ;bias_i_depent(index)+var_i_depent(index) ]  

t_iid= [ sqrt(bias_t(index))  *10; bias_t(index)+var_t(index)  ]  
t_depend= [ sqrt(bias_t_depent(index))  *10; bias_t_depent(index)+var_t_depent(index)  ]  

 

hom_iid= [   sqrt(bias_hom(index))  *10;bias_hom(index)+var_hom(index)  ]  
hom_depend= [   sqrt(bias_hom_depent(index))  *10;  bias_hom_depent(index)+ var_hom_depent(index) ]  

twoway_iid= [   sqrt(bias_2way(index))  *10; bias_2way(index)+var_2way(index) ]  
twoway_depend= [   sqrt(bias_2way_depent(index))  *10;  bias_2way_depent(index)+ var_2way_depent(index) ]     

   
%% coverage iid case
 [cover_hetero(1) ;cover_i(1); cover_t(1);  cover_hom(1); cover_2way(1) ]

 %% coverage time dependent case 
 [cover_depent(1); cover_i_depent(1); cover_t_depent(1); cover_hom_depent(1);  cover_2way_depent(1)  ]