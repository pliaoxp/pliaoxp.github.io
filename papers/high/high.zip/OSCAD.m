
function f2=OSCAD(z,lambda)
% origninal function of SCAD, instead of the derivatives.
% z can be negative;
a=3.7;
alpha=-(2*a-2)^(-1);
b=a*lambda/(a-1);
c=lambda^2/(2-2*a);
u=abs(z);
if u<lambda
    f2=lambda*u;
else if u<a*lambda
        f2=alpha*u^2+b*u+c;
    else f2=(1+a)*lambda^2/2;
    end;
end;
    