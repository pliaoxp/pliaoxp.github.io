function f=PLS(beta,y,X,lambda)
% f=objective function
% X is p by n.
n=length(y);
p=length(beta);

h=(y-X'*beta)'*(y-X'*beta)/n;

  
P=0;
for j=1:p
    P=P+OSCAD(abs(beta(j)),lambda);
end;
f=h+P;


function g=SCAD(z,lambda)
% derivative
% z>=0
a=3.7;
if z<lambda
    g=lambda;
else if z<a*lambda
        g=-z/(a-1)+a*lambda/(a-1);
    else g=0;
    end;
end;


function f2=OSCAD(z,lambda)
% origninal function of SCAD, instead of the derivatives.
% z can be negative;
a=3.7;
alpha=-(2*a-2)^(-1);
b=a*lambda/(a-1);
c=lambda^2/(2-2*a);
u=abs(z);
if u<lambda
    f2=lambda*u;
else if u<a*lambda
        f2=alpha*u^2+b*u+c;
    else f2=(1+a)*lambda^2/2;
    end;
end;