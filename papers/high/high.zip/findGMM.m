function f=findGMM(t,betaold,q1,q2,y,X,lambda,sigma) 
% q1, q2, X p by n
n=length(y);
p=length(betaold);
Bj=X(t,:)*q1(t,:)'/n;
Cj=X(t,:)*q2(t,:)'/n;
op1=0;op2=0;
for m=1:p
    A(m)=q1(m,:)*(y-X'*betaold)/n;
    H(m)=q2(m,:)*(y-X'*betaold)/n;
    b(m)=smooth(betaold(m),sigma)*X(t,:)*q1(m,:)'/n;
    d(m)=smooth(betaold(m),sigma)*X(t,:)*q2(m,:)'/n;
    op1=op1-2*A(m)*b(m)*smooth(betaold(m),sigma);
    op2=op2-2*H(m)*d(m)*smooth(betaold(m),sigma);
end;
z1=betaold(t)^2/sigma;
%K1=4*betaold(t)/sigma*normpdf(z1);
%K2=4/sigma*normpdf(z1)+8*betaold(t)^2/sigma^2*(-z1/sqrt(2*pi)*exp(-z1^2/2));
K1=firstderiv(betaold(t),sigma);
K2=secondderiv(betaold(t),sigma);

l1=op1+2*A(t)^2*smooth(betaold(t),sigma)*K1+op2+2*H(t)^2*smooth(betaold(t),sigma)*K1;
l2=2*norm(b)^2+2*norm(d)^2+2*(A(t)^2+H(t)^2)*(K1^2+smooth(betaold(t),sigma)*K2)-8*smooth(betaold(t),sigma)*K1*(A(t)*Bj+H(t)*Cj);
z=betaold(t)-l1/l2; Lamb=1/l2;
z0=sign(z)*max(0,abs(z)-Lamb*lambda);
Rz0=1/2*(z-z0)^2+Lamb*OSCAD(abs(z0),lambda);
Rz=Lamb*OSCAD(abs(z),lambda);

a=3.7;
if abs(z)<=lambda f=z0;
end;
if abs(z)>a*lambda
        if abs(z)<=(Lamb+1)*lambda
            if Rz0<=Rz
                f=z0;
            else f=z;
            end;
        else f=z;
        end;
end;
if abs(z)>lambda && abs(z)<=a*lambda
        if abs(z)<=(Lamb+1)*lambda
           f=z0;
        else tr=abs(z)-Lamb*lambda*a/(a-1);
            tp=1-Lamb/(a-1);
             f=sign(z)*tr/tp;
        end;
end;



function g=SCAD(z,lambda)
% derivative
% z>=0
a=3.7;
if z<lambda
    g=lambda;
else if z<a*lambda
        g=-z/(a-1)+a*lambda/(a-1);
    else g=0;
    end;
end;


function f2=OSCAD(z,lambda)
% origninal function of SCAD, instead of the derivatives.
% z can be negative;
a=3.7;
alpha=-(2*a-2)^(-1);
b=a*lambda/(a-1);
c=lambda^2/(2-2*a);
u=abs(z);
if u<lambda
    f2=lambda*u;
else if u<a*lambda
        f2=alpha*u^2+b*u+c;
    else f2=(1+a)*lambda^2/2;
    end;
end;
