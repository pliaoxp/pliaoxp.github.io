function f=findPLS(t,betaold,y,X,lambda)
% f=optimal betat
% X is p by n.
n=length(y);
p=length(betaold);
beta=betaold;
if t==1
    X2=X(2:p,:);
    beta2=beta(2:p);
else if t==p
        X2=X(1:p-1,:);
        beta2=beta(1:p-1);
    else
        X2=[X(1:t-1,:);X(t+1:p,:)];  % no xt
        beta2=[beta(1:t-1);beta(t+1:p)];
    end;
end;

a=3.7;
c=norm(X(t,:))^2;
b=0;
for i=1:n
    b=b+X(t,i)*(y(i)-X2(:,i)'*beta2);
end;
z=b/c;
Lamb=1/(2*c);
z0=sign(z)*max(0,abs(z)-Lamb*lambda);
Rz0=1/2*(z-z0)^2+Lamb*OSCAD(abs(z0),lambda);
Rz=Lamb*OSCAD(abs(z),lambda);



if abs(z)<=lambda f=z0;
end;

if abs(z)>a*lambda
        if abs(z)<=(Lamb+1)*lambda
            if Rz0<=Rz
                f=z0;
            else f=z;
            end;
        else f=z;
        end;
end;
if abs(z)>lambda && abs(z)<=a*lambda
        if abs(z)<=(Lamb+1)*lambda
           f=z0;
        else tr=abs(z)-Lamb*lambda*a/(a-1);
            tp=1-Lamb/(a-1);
             f=sign(z)*tr/tp;
        end;
end;

   






function g=SCAD(z,lambda)
% derivative
% z>=0
a=3.7;
if z<lambda
    g=lambda;
else if z<a*lambda
        g=-z/(a-1)+a*lambda/(a-1);
    else g=0;
    end;
end;


function f2=OSCAD(z,lambda)
% origninal function of SCAD, instead of the derivatives.
% z can be negative;
a=3.7;
alpha=-(2*a-2)^(-1);
b=a*lambda/(a-1);
c=lambda^2/(2-2*a);
u=abs(z);
if u<lambda
    f2=lambda*u;
else if u<a*lambda
        f2=alpha*u^2+b*u+c;
    else f2=(1+a)*lambda^2/2;
    end;
end;