function f=firstderiv(beta,sigma)
if abs(beta)>1.5
    f=0;
else z=beta^2/sigma; 
    f=4*beta/sigma*(exp(-z)+exp(z)+2)^(-1);
end;