function f=objGMM(X,y,betaold,q1,q2,sigma,lambda)
% X is p by n.
% y is n by 1.

n=length(y);
p=length(betaold);
f2=0;
for m=1:p
    A(m)=q1(m,:)*(y-X'*betaold)/n*smooth(betaold(m),sigma);
    H(m)=q2(m,:)*(y-X'*betaold)/n*smooth(betaold(m),sigma);
    f2=f2+OSCAD(abs(betaold(m)),lambda);
end;
f1=norm(A)^2+norm(H)^2;
f=f1+f2;



