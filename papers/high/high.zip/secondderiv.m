function f=secondderiv(beta,sigma)
z=beta^2/sigma;
if abs(beta)>1.5
    f=0;
else
    f=8*beta^2/sigma^2*(exp(-z)-exp(z))/(exp(-z)+exp(z)+2)^2+4/sigma*(exp(-z)+exp(z)+2)^(-1);
end;
