
function g=smooth(beta,sigma)
x=beta^2/sigma;
if beta==0
    g=0;
else if abs(beta)>2
        g=1;
    else 
    %g1=normcdf(x);
    g1=exp(x)/(1+exp(x));
    g=(g1-0.5)/0.5;
    end;
   
    
end;

% as long as beta^2>2*sigma, g is about 1.

%if x>5 g1=1;
%else g1=0.5+(105/64)*((x/5)-(5/3)*(x/5)^3+(7/5)*(x/5)^5-(3/7)*(x/5)^7);
%end;
%g=(g1-0.5)/0.5;
